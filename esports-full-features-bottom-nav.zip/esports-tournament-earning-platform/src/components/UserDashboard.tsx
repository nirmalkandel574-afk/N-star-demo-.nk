import React, { useState, useEffect } from 'react';
import { 
  User, Tournament, Transaction, AdminConfig,
  getUsers, saveUsers, getTournaments, saveTournaments, 
  getTransactions, saveTransactions, getConfig, addLog 
} from '../utils/db';
import { SpinWheel } from './SpinWheel';
import { 
  User as UserIcon, Wallet, Trophy, Users, Bell, Gift, 
  Award, Edit3, Image, LogOut, ArrowUpRight, ArrowDownLeft, 
  CheckCircle, Clock, XCircle, Copy, Unlock, Calendar, Gamepad2
} from 'lucide-react';

interface UserDashboardProps {
  currentUser: User;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
  notify: (msg: string, type: 'success' | 'error' | 'info') => void;
  initialTab?: string;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  currentUser,
  onLogout,
  onUpdateUser,
  notify,
  initialTab = 'profile',
}) => {
  const [activeTab, setActiveTab] = useState<string>(initialTab);
  
  // Database state
  const [users, setUsers] = useState<User[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [adminConfig, setAdminConfig] = useState<AdminConfig | null>(null);

  // Profile Edit State
  const [editUsername, setEditUsername] = useState(currentUser.username);
  const [editPhone, setEditPhone] = useState(currentUser.phone);
  const [editAvatar, setEditAvatar] = useState(currentUser.avatarUrl);
  const [ffNickname, setFfNickname] = useState(currentUser.gameNicknames?.freeFire || '');
  const [pubgNickname, setPubgNickname] = useState(currentUser.gameNicknames?.pubg || '');
  const [mlbbNickname, setMlbbNickname] = useState(currentUser.gameNicknames?.mlbb || '');
  const [efootballNickname, setEfootballNickname] = useState(currentUser.gameNicknames?.efootball || '');
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // Wallet Forms State
  const [depositMethod, setDepositMethod] = useState<'eSewa' | 'Khalti'>('eSewa');
  const [depositAmount, setDepositAmount] = useState<number>(10);
  const [depositTxnId, setDepositTxnId] = useState('');
  const [depositScreenshot, setDepositScreenshot] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState<'eSewa' | 'Khalti'>('eSewa');
  const [withdrawAmount, setWithdrawAmount] = useState<number>(50);
  const [withdrawPhone, setWithdrawPhone] = useState('');
  const [withdrawName, setWithdrawName] = useState('');

  // Daily Login State
  const [canClaimDaily, setCanClaimDaily] = useState(true);

  // Tournament Filters
  const [tourFilter, setTourFilter] = useState<'all' | 'joined' | 'upcoming'>('all');
  const [selectedTour, setSelectedTour] = useState<Tournament | null>(null);
  const [joinNickname, setJoinNickname] = useState('');
  const [isJoiningModalOpen, setIsJoiningModalOpen] = useState(false);

  // Load Data
  const loadData = () => {
    setUsers(getUsers());
    setTournaments(getTournaments());
    setTransactions(getTransactions());
    setAdminConfig(getConfig());
    checkDailyLoginStatus();
  };

  useEffect(() => {
    loadData();
    // Periodically update data
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const checkDailyLoginStatus = () => {
    const today = new Date().toDateString();
    if (currentUser.lastLoginDate === today) {
      setCanClaimDaily(false);
    } else {
      setCanClaimDaily(true);
    }
  };

  const handleClaimDailyLogin = () => {
    const today = new Date().toDateString();
    
    // Choose random login reward (Rs. 1 to Rs. 5)
    const reward = Math.floor(Math.random() * 5) + 1;
    
    const allUsers = getUsers();
    const uIdx = allUsers.findIndex(u => u.id === currentUser.id);
    if (uIdx === -1) return;

    const updated = {
      ...allUsers[uIdx],
      walletBalance: Number((allUsers[uIdx].walletBalance + reward).toFixed(2)),
      lastLoginDate: today,
    };
    
    // Add badge if not already added
    if (!updated.badges.includes('Daily Striker')) {
      updated.badges.push('Daily Striker');
    }

    allUsers[uIdx] = updated;
    saveUsers(allUsers);

    // Create system transaction
    const txs = getTransactions();
    txs.unshift({
      id: 'tx_daily_' + Date.now(),
      userId: currentUser.id,
      username: currentUser.username,
      type: 'daily_login',
      amount: reward,
      method: 'System',
      status: 'approved',
      createdAt: new Date().toISOString()
    });
    saveTransactions(txs);

    addLog(currentUser.id, currentUser.username, `Claimed daily login reward: Rs. ${reward}`);
    notify(`Daily reward claimed successfully! Rs. ${reward} credited.`, 'success');
    onUpdateUser(updated);
    loadData();
  };

  // Profile update
  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editUsername || !editPhone) {
      notify('Username and phone number are required.', 'error');
      return;
    }

    const allUsers = getUsers();
    const uIdx = allUsers.findIndex(u => u.id === currentUser.id);
    if (uIdx === -1) return;

    // Check username uniqueness
    if (allUsers.some(u => u.id !== currentUser.id && u.username.toLowerCase() === editUsername.toLowerCase())) {
      notify('Username is already taken.', 'error');
      return;
    }

    const updated: User = {
      ...allUsers[uIdx],
      username: editUsername,
      phone: editPhone,
      avatarUrl: editAvatar,
      gameNicknames: {
        freeFire: ffNickname,
        pubg: pubgNickname,
        mlbb: mlbbNickname,
        efootball: efootballNickname
      }
    };

    allUsers[uIdx] = updated;
    saveUsers(allUsers);
    addLog(currentUser.id, currentUser.username, 'Updated profile details & game nicknames');
    notify('Profile updated successfully!', 'success');
    onUpdateUser(updated);
    setIsEditingProfile(false);
    loadData();
  };

  // Submit Deposit Request
  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const minD = adminConfig?.minDeposit || 10;

    if (depositAmount < minD) {
      notify(`Minimum deposit is Rs. ${minD}`, 'error');
      return;
    }

    if (!depositTxnId.trim()) {
      notify('Transaction ID is required.', 'error');
      return;
    }

    // Security check: Prevent duplicate transaction IDs
    const txs = getTransactions();
    const isDuplicate = txs.some(
      t => t.transactionId?.trim().toLowerCase() === depositTxnId.trim().toLowerCase()
    );

    if (isDuplicate) {
      notify('This Transaction ID has already been submitted or processed. Fraudulent inputs are monitored.', 'error');
      addLog(currentUser.id, currentUser.username, `SECURITY ALERT: Duplicate deposit txn ID attempt: ${depositTxnId}`);
      return;
    }

    // Save screenshot (or generate dummy if empty)
    const screenshot = depositScreenshot.trim() || 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=400';

    const newTx: Transaction = {
      id: 'tx_dep_' + Date.now(),
      userId: currentUser.id,
      username: currentUser.username,
      type: 'deposit',
      amount: depositAmount,
      method: depositMethod,
      transactionId: depositTxnId.trim(),
      screenshotUrl: screenshot,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    txs.unshift(newTx);
    saveTransactions(txs);
    addLog(currentUser.id, currentUser.username, `Submitted deposit request: Rs. ${depositAmount} via ${depositMethod}`);
    notify('Deposit request submitted! Admin will verify in 5-15 minutes.', 'success');

    // Reset fields
    setDepositAmount(minD);
    setDepositTxnId('');
    setDepositScreenshot('');
    loadData();
  };

  // Submit Withdrawal Request
  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const minW = adminConfig?.minWithdraw || 50;

    if (withdrawAmount < minW) {
      notify(`Minimum withdrawal amount is Rs. ${minW}`, 'error');
      return;
    }

    if (withdrawAmount > currentUser.walletBalance) {
      notify('Insufficient wallet balance for this withdrawal.', 'error');
      return;
    }

    if (!withdrawPhone || !withdrawName) {
      notify('All payment fields are required.', 'error');
      return;
    }

    // Deduct immediately (or place on lock) to prevent double spending
    const allUsers = getUsers();
    const uIdx = allUsers.findIndex(u => u.id === currentUser.id);
    if (uIdx === -1) return;

    const updatedUser = {
      ...allUsers[uIdx],
      walletBalance: Number((allUsers[uIdx].walletBalance - withdrawAmount).toFixed(2))
    };

    allUsers[uIdx] = updatedUser;
    saveUsers(allUsers);

    // Create withdrawal request
    const txs = getTransactions();
    const newTx: Transaction = {
      id: 'tx_wdr_' + Date.now(),
      userId: currentUser.id,
      username: currentUser.username,
      type: 'withdrawal',
      amount: withdrawAmount,
      method: withdrawMethod,
      accountNo: withdrawPhone,
      accountName: withdrawName,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    txs.unshift(newTx);
    saveTransactions(txs);

    addLog(currentUser.id, currentUser.username, `Submitted withdrawal request: Rs. ${withdrawAmount} to ${withdrawPhone}`);
    notify('Withdrawal requested! Amount locked. Approval is processed soon.', 'success');

    onUpdateUser(updatedUser);
    
    // Reset forms
    setWithdrawAmount(minW);
    setWithdrawPhone('');
    setWithdrawName('');
    loadData();
  };

  // Join Tournament
  const handleJoinTournamentClick = (tour: Tournament) => {
    // Check if user is already registered
    if (tour.registeredPlayers.includes(currentUser.id)) {
      setSelectedTour(tour);
      setActiveTab('tournaments');
      return;
    }

    // Identify tournament game nickname
    let nickname = '';
    if (tour.game === 'Free Fire') nickname = currentUser.gameNicknames?.freeFire || '';
    if (tour.game === 'PUBG Mobile') nickname = currentUser.gameNicknames?.pubg || '';
    if (tour.game === 'Mobile Legends') nickname = currentUser.gameNicknames?.mlbb || '';
    if (tour.game === 'eFootball') nickname = currentUser.gameNicknames?.efootball || '';

    setJoinNickname(nickname);
    setSelectedTour(tour);
    setIsJoiningModalOpen(true);
  };

  const confirmJoinTournament = () => {
    if (!selectedTour) return;
    if (!joinNickname.trim()) {
      notify('Please enter your game nickname/ID.', 'error');
      return;
    }

    if (selectedTour.registeredPlayers.length >= selectedTour.totalSlots) {
      notify('This tournament is already full!', 'error');
      return;
    }

    // Check entry fee
    if (currentUser.walletBalance < selectedTour.entryFee) {
      notify('Insufficient wallet balance to join this tournament. Please deposit funds.', 'error');
      return;
    }

    const allUsers = getUsers();
    const userIndex = allUsers.findIndex(u => u.id === currentUser.id);
    const allTours = getTournaments();
    const tourIndex = allTours.findIndex(t => t.id === selectedTour.id);

    if (userIndex === -1 || tourIndex === -1) return;

    // Deduct Entry Fee
    const updatedUser = {
      ...allUsers[userIndex],
      walletBalance: Number((allUsers[userIndex].walletBalance - selectedTour.entryFee).toFixed(2)),
      badges: allUsers[userIndex].badges.includes('Esports Champ') 
        ? allUsers[userIndex].badges 
        : [...allUsers[userIndex].badges, 'Esports Champ']
    };

    // Add game nickname if not already saved to user profile
    if (!updatedUser.gameNicknames) updatedUser.gameNicknames = {};
    if (selectedTour.game === 'Free Fire') updatedUser.gameNicknames.freeFire = joinNickname;
    if (selectedTour.game === 'PUBG Mobile') updatedUser.gameNicknames.pubg = joinNickname;
    if (selectedTour.game === 'Mobile Legends') updatedUser.gameNicknames.mlbb = joinNickname;
    if (selectedTour.game === 'eFootball') updatedUser.gameNicknames.efootball = joinNickname;

    allUsers[userIndex] = updatedUser;
    saveUsers(allUsers);

    // Update Tournament Participants
    const updatedTour = { ...allTours[tourIndex] };
    updatedTour.registeredPlayers.push(currentUser.id);
    updatedTour.participants.push({
      userId: currentUser.id,
      username: currentUser.username,
      gameNickname: joinNickname
    });
    
    allTours[tourIndex] = updatedTour;
    saveTournaments(allTours);

    // Create entry fee transaction log
    if (selectedTour.entryFee > 0) {
      const txs = getTransactions();
      txs.unshift({
        id: 'tx_entry_' + Date.now(),
        userId: currentUser.id,
        username: currentUser.username,
        type: 'tournament_entry',
        amount: selectedTour.entryFee,
        method: 'System',
        status: 'approved',
        createdAt: new Date().toISOString()
      });
      saveTransactions(txs);
    }

    addLog(currentUser.id, currentUser.username, `Joined tournament: ${selectedTour.title}`);
    notify(`Successfully joined ${selectedTour.title}! Slot confirmed.`, 'success');

    onUpdateUser(updatedUser);
    setIsJoiningModalOpen(false);
    setSelectedTour(updatedTour);
    loadData();
  };

  const copyReferralLink = () => {
    const link = `${window.location.origin}?ref=${currentUser.referralCode}`;
    navigator.clipboard.writeText(link);
    notify('Referral link copied to clipboard!', 'success');
  };

  // Preset avatars for profile customization
  const presetAvatars = [
    `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.username}`,
    `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.username}`,
    `https://api.dicebear.com/7.x/pixel-art/svg?seed=ninja`,
    `https://api.dicebear.com/7.x/pixel-art/svg?seed=samurai`,
    `https://api.dicebear.com/7.x/pixel-art/svg?seed=cyborg`,
  ];

  // Filters notifications from transaction approvals
  const userTransactions = transactions.filter(t => t.userId === currentUser.id);

  // Quick stats
  const totalEarned = userTransactions
    .filter(t => t.status === 'approved' && (t.type === 'tournament_win' || t.type === 'referral' || t.type === 'daily_spin' || t.type === 'daily_login'))
    .reduce((acc, t) => acc + t.amount, 0);

  const totalSpent = userTransactions
    .filter(t => t.status === 'approved' && t.type === 'tournament_entry')
    .reduce((acc, t) => acc + t.amount, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row font-sans">
      
      {/* 1. Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 border-r border-slate-800 p-6 flex flex-col justify-between flex-shrink-0">
        
        <div>
          {/* Header brand logo */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 shadow-[0_0_15px_rgba(6,182,212,0.4)] flex items-center justify-center font-black text-white text-base">
              N
            </div>
            <h2 className="text-lg font-black tracking-wider text-white">
              NIMZ <span className="bg-gradient-to-r from-cyan-400 to-violet-400 bg-clip-text text-transparent">BATTLE</span>
            </h2>
          </div>

          {/* User mini badge */}
          <div className="flex items-center gap-3 p-3 bg-slate-950 rounded-2xl border border-slate-800 mb-8">
            <img src={currentUser.avatarUrl} alt="Avatar" className="w-10 h-10 rounded-full border border-violet-800 bg-slate-900" />
            <div className="overflow-hidden">
              <h3 className="font-extrabold text-white text-sm truncate">{currentUser.username}</h3>
              <p className="text-[10px] text-emerald-400 font-bold">Rs. {currentUser.walletBalance}</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('profile')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'profile' ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <UserIcon className="w-5 h-5" />
              My Profile
            </button>

            <button
              onClick={() => setActiveTab('tournaments')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'tournaments' ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Trophy className="w-5 h-5" />
              Tournaments
            </button>

            <button
              onClick={() => setActiveTab('wallet')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'wallet' ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Wallet className="w-5 h-5" />
              My Wallet
            </button>

            <button
              onClick={() => setActiveTab('referrals')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'referrals' ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Users className="w-5 h-5" />
              Refer & Earn
            </button>

            <button
              onClick={() => setActiveTab('spin')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'spin' ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Gift className="w-5 h-5" />
              Spin & Win
            </button>

            <button
              onClick={() => setActiveTab('notifications')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center justify-between cursor-pointer ${
                activeTab === 'notifications' ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <span className="flex items-center gap-3">
                <Bell className="w-5 h-5" />
                Alerts Center
              </span>
              {userTransactions.filter(t => t.status === 'pending').length > 0 && (
                <span className="w-5 h-5 bg-rose-600 text-white rounded-full flex items-center justify-center text-[10px] font-black">
                  {userTransactions.filter(t => t.status === 'pending').length}
                </span>
              )}
            </button>
          </nav>
        </div>

        {/* Footer actions */}
        <div className="mt-8 pt-4 border-t border-slate-800">
          <button
            onClick={onLogout}
            className="w-full py-2.5 px-4 rounded-xl text-rose-500 hover:text-rose-400 hover:bg-rose-950/20 font-bold text-sm transition-all flex items-center gap-3 cursor-pointer"
          >
            <LogOut className="w-5 h-5" />
            Log Out Account
          </button>
        </div>
      </aside>

      {/* 2. Main Tab Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto max-w-7xl">
        
        {/* Profile / Overview Tab */}
        {activeTab === 'profile' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            
            {/* Header statistics */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                  Combat <span className="text-cyan-400">Dashboard</span>
                </h2>
                <p className="text-slate-400 text-xs mt-1">Monitor profile badges, game settings, and statistics</p>
              </div>

              {canClaimDaily && (
                <button
                  onClick={handleClaimDailyLogin}
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(16,185,129,0.3)] animate-bounce cursor-pointer"
                >
                  🎁 Collect Daily Login Reward (Rs. 1-5)
                </button>
              )}
            </div>

            {/* Quick Stat Indicators */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-cyan-950/40 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
                  <Wallet className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-semibold uppercase">Wallet Cash</p>
                  <p className="text-xl font-extrabold text-white">Rs. {currentUser.walletBalance}</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-violet-950/40 border border-violet-800/60 flex items-center justify-center text-violet-400">
                  <Gift className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-semibold uppercase">Bonus Coins</p>
                  <p className="text-xl font-extrabold text-white">{currentUser.bonusCoins}</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-950/40 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
                  <ArrowUpRight className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-semibold uppercase">Total Earned</p>
                  <p className="text-xl font-extrabold text-white">Rs. {totalEarned}</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-rose-950/40 border border-rose-800/60 flex items-center justify-center text-rose-400">
                  <ArrowDownLeft className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-semibold uppercase">Total Spent</p>
                  <p className="text-xl font-extrabold text-white">Rs. {totalSpent}</p>
                </div>
              </div>
            </div>

            {/* Profile Detail Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Profile Details Edit Card */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-black text-white uppercase tracking-wider">Profile Information</h3>
                  {!isEditingProfile && (
                    <button
                      onClick={() => setIsEditingProfile(true)}
                      className="px-4 py-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      Edit Details
                    </button>
                  )}
                </div>

                {isEditingProfile ? (
                  <form onSubmit={handleUpdateProfile} className="space-y-6">
                    {/* Avatar selection grid */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                        <Image className="w-4 h-4 text-cyan-400" />
                        Choose Gamer Avatar
                      </label>
                      <div className="flex gap-4 overflow-x-auto pb-2">
                        {presetAvatars.map((url, i) => (
                          <button
                            type="button"
                            key={i}
                            onClick={() => setEditAvatar(url)}
                            className={`w-14 h-14 rounded-full border-2 bg-slate-950 flex-shrink-0 transition-all ${
                              editAvatar === url ? 'border-cyan-400 scale-105 shadow-md shadow-cyan-400/20' : 'border-slate-800 opacity-60'
                            }`}
                          >
                            <img src={url} alt="Avatar" className="w-full h-full rounded-full" />
                          </button>
                        ))}
                      </div>
                      
                      <div className="mt-3">
                        <label className="block text-xs text-slate-500 font-semibold mb-1">Custom Image URL (Optional)</label>
                        <input
                          type="text"
                          value={editAvatar}
                          onChange={(e) => setEditAvatar(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Username</label>
                        <input
                          type="text"
                          required
                          value={editUsername}
                          onChange={(e) => setEditUsername(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Phone</label>
                        <input
                          type="tel"
                          required
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        />
                      </div>
                    </div>

                    <div className="border-t border-slate-850 pt-6">
                      <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                        <Gamepad2 className="w-4 h-4 text-violet-400" />
                        In-Game Nicknames (For Automating Room Lobby)
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs text-slate-500 font-semibold mb-2">Free Fire ID</label>
                          <input
                            type="text"
                            placeholder="e.g. FF_Gamer_X"
                            value={ffNickname}
                            onChange={(e) => setFfNickname(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-slate-500 font-semibold mb-2">PUBG Mobile ID</label>
                          <input
                            type="text"
                            placeholder="e.g. PUBG_Pro"
                            value={pubgNickname}
                            onChange={(e) => setPubgNickname(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-slate-500 font-semibold mb-2">Mobile Legends ID</label>
                          <input
                            type="text"
                            placeholder="e.g. MLBB_Champ"
                            value={mlbbNickname}
                            onChange={(e) => setMlbbNickname(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-slate-500 font-semibold mb-2">eFootball ID</label>
                          <input
                            type="text"
                            placeholder="e.g. PES_Striker"
                            value={efootballNickname}
                            onChange={(e) => setEfootballNickname(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <button
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-cyan-500 to-violet-600 text-white font-bold py-3 px-4 rounded-xl text-sm"
                      >
                        Save Configuration
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditingProfile(false)}
                        className="px-6 py-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-sm font-semibold"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">User Role</p>
                          <p className="text-sm font-bold text-white uppercase flex items-center gap-1.5 mt-0.5">
                            {currentUser.role}
                            {currentUser.role === 'admin' && (
                              <span className="bg-rose-950 border border-rose-800 text-rose-400 text-[10px] px-2 py-0.5 rounded font-black">
                                Staff
                              </span>
                            )}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Email Address</p>
                          <p className="text-sm font-bold text-white mt-0.5">{currentUser.email}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Phone Number</p>
                          <p className="text-sm font-bold text-white mt-0.5">{currentUser.phone || 'N/A'}</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Free Fire ID</p>
                          <p className="text-sm font-bold text-slate-200 mt-0.5">{currentUser.gameNicknames?.freeFire || 'Not set'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">PUBG Mobile ID</p>
                          <p className="text-sm font-bold text-slate-200 mt-0.5">{currentUser.gameNicknames?.pubg || 'Not set'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">MLBB ID</p>
                          <p className="text-sm font-bold text-slate-200 mt-0.5">{currentUser.gameNicknames?.mlbb || 'Not set'}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">eFootball ID</p>
                          <p className="text-sm font-bold text-slate-200 mt-0.5">{currentUser.gameNicknames?.efootball || 'Not set'}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Achievements & Badges List */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6 flex items-center gap-2">
                    <Award className="w-5 h-5 text-yellow-500" />
                    My Badges
                  </h3>

                  <div className="grid grid-cols-2 gap-4">
                    {currentUser.badges.map((badge, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-950 border border-slate-850 p-3 rounded-2xl text-center space-y-1.5 shadow-md"
                      >
                        <div className="w-9 h-9 rounded-full bg-violet-950 border border-violet-800 mx-auto flex items-center justify-center text-sm">
                          {badge === 'Platform Founder' ? '👑' : badge === 'Newbie' ? '🌱' : badge === 'Early Adopter' ? '🚀' : '⚔️'}
                        </div>
                        <p className="text-[10px] font-black text-slate-200 uppercase tracking-wide truncate">{badge}</p>
                      </div>
                    ))}
                    {currentUser.badges.length === 0 && (
                      <p className="text-xs text-slate-500 col-span-2 text-center py-6">Unlock achievements to earn game badges!</p>
                    )}
                  </div>
                </div>

                <div className="mt-8 border-t border-slate-850 pt-6">
                  <h4 className="text-xs font-bold text-slate-400 uppercase mb-3">Next Milestone</h4>
                  <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                    <div className="bg-gradient-to-r from-cyan-500 to-violet-600 h-full w-2/3" />
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1.5">Refer 5 friends to unlock the "Top Recruiter" Badge.</p>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Find Tournaments Tab */}
        {activeTab === 'tournaments' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Trophy className="w-7 h-7 text-cyan-400" />
                Tournament <span className="bg-gradient-to-r from-cyan-400 to-violet-500 bg-clip-text text-transparent">Nexus</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Browse, join tournaments and view room passwords & bracket details</p>
            </div>

            {/* Toggle filter tabs */}
            <div className="flex bg-slate-900/60 p-1.5 rounded-xl border border-slate-800 text-xs max-w-xs">
              <button
                onClick={() => setTourFilter('all')}
                className={`flex-1 py-2 rounded-lg font-bold transition-all ${
                  tourFilter === 'all' ? 'bg-cyan-500 text-black' : 'text-slate-400'
                }`}
              >
                All Matches
              </button>
              <button
                onClick={() => setTourFilter('joined')}
                className={`flex-1 py-2 rounded-lg font-bold transition-all ${
                  tourFilter === 'joined' ? 'bg-cyan-500 text-black' : 'text-slate-400'
                }`}
              >
                My Entries
              </button>
              <button
                onClick={() => setTourFilter('upcoming')}
                className={`flex-1 py-2 rounded-lg font-bold transition-all ${
                  tourFilter === 'upcoming' ? 'bg-cyan-500 text-black' : 'text-slate-400'
                }`}
              >
                Upcoming
              </button>
            </div>

            {/* Grid list of matches */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {tournaments
                .filter(t => {
                  if (tourFilter === 'joined') return t.registeredPlayers.includes(currentUser.id);
                  if (tourFilter === 'upcoming') return t.status === 'upcoming';
                  return true;
                })
                .map((tour) => {
                  const isJoined = tour.registeredPlayers.includes(currentUser.id);
                  return (
                    <div
                      key={tour.id}
                      className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-violet-850 hover:shadow-lg transition-all"
                    >
                      <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-black uppercase bg-violet-950 border border-violet-800 text-violet-400 px-2.5 py-0.5 rounded">
                              {tour.game}
                            </span>
                            <span className="text-[10px] font-semibold text-slate-500 uppercase">
                              {tour.format} | {tour.bracketType}
                            </span>
                            {tour.status === 'ongoing' && (
                              <span className="text-[10px] font-black uppercase bg-red-950 border border-red-800 text-rose-500 px-2 py-0.5 rounded animate-pulse">
                                Live
                              </span>
                            )}
                          </div>
                          
                          <h3 className="text-xl font-bold text-white">{tour.title}</h3>
                          
                          <p className="text-xs text-slate-400 flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                            Match Time: {new Date(tour.startTime).toLocaleString()}
                          </p>
                        </div>

                        {/* Banner image or icon placeholder */}
                        <div className="w-full sm:w-24 h-16 rounded-xl bg-slate-950 overflow-hidden relative border border-slate-800">
                          <img src={tour.bannerUrl} alt="Banner" className="w-full h-full object-cover" />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 my-6 text-center">
                        <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-850">
                          <p className="text-[10px] text-slate-500 font-semibold uppercase">Prize Pool</p>
                          <p className="text-sm font-extrabold text-emerald-400">Rs. {tour.prizePool}</p>
                        </div>
                        <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-850">
                          <p className="text-[10px] text-slate-500 font-semibold uppercase">Entry Fee</p>
                          <p className="text-sm font-extrabold text-slate-200">
                            {tour.entryFee === 0 ? 'FREE' : `Rs. ${tour.entryFee}`}
                          </p>
                        </div>
                        <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-850">
                          <p className="text-[10px] text-slate-500 font-semibold uppercase">Participants</p>
                          <p className="text-sm font-extrabold text-cyan-400">
                            {tour.registeredPlayers.length} / {tour.totalSlots}
                          </p>
                        </div>
                      </div>

                      {/* Participant Lobbies or Room Details */}
                      {isJoined && (
                        <div className="bg-violet-950/30 border border-violet-850/60 p-4 rounded-2xl mb-6 space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-xs text-violet-400 font-bold flex items-center gap-1.5">
                              <Unlock className="w-4 h-4" />
                              Room Credentials (Visible to Players)
                            </span>
                            <span className="text-[10px] uppercase font-black bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded">
                              Joined
                            </span>
                          </div>

                          {tour.roomDetails?.roomId ? (
                            <div className="grid grid-cols-2 gap-4 pt-2">
                              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-900">
                                <p className="text-[9px] text-slate-500 font-bold">ROOM ID</p>
                                <p className="text-sm font-black text-white select-all">{tour.roomDetails.roomId}</p>
                              </div>
                              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-900">
                                <p className="text-[9px] text-slate-500 font-bold">ROOM PASSWORD</p>
                                <p className="text-sm font-black text-white select-all">{tour.roomDetails.roomPassword || 'None'}</p>
                              </div>
                            </div>
                          ) : (
                            <p className="text-xs text-slate-400 italic pt-1">
                              Room credentials will appear 15 minutes before the match start time. Ensure you check this section.
                            </p>
                          )}
                        </div>
                      )}

                      {/* Results display */}
                      {tour.status === 'completed' && tour.winners && (
                        <div className="bg-amber-950/20 border border-amber-800/40 p-4 rounded-2xl mb-6">
                          <p className="text-xs text-amber-500 font-bold mb-2">🏆 Tournament Standings</p>
                          <div className="space-y-1.5">
                            {tour.winners.map((w, index) => (
                              <div key={index} className="flex justify-between items-center text-xs font-semibold">
                                <span className="text-slate-300">
                                  Rank #{w.rank}: <span className="font-extrabold text-white">{w.username}</span>
                                </span>
                                <span className="text-emerald-400">Rs. {w.prize}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Bottom Button Action */}
                      <button
                        onClick={() => handleJoinTournamentClick(tour)}
                        className={`w-full py-3 rounded-xl font-bold transition-all text-sm cursor-pointer flex items-center justify-center gap-2 ${
                          tour.status === 'completed'
                            ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                            : isJoined
                            ? 'bg-violet-900/30 text-violet-400 border border-violet-850 hover:bg-violet-900/40'
                            : 'bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white'
                        }`}
                      >
                        {tour.status === 'completed' ? (
                          'Tournament Completed'
                        ) : isJoined ? (
                          'Joined (Tap to view details)'
                        ) : (
                          `Join Tournament (Fee: Rs. ${tour.entryFee})`
                        )}
                      </button>
                    </div>
                  );
                })}

              {tournaments.length === 0 && (
                <div className="col-span-2 text-center py-20 bg-slate-900/40 rounded-3xl border border-slate-850">
                  <p className="text-slate-500 font-bold">No registered tournaments found at the moment.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* My Wallet Tab */}
        {activeTab === 'wallet' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Wallet className="w-7 h-7 text-cyan-400" />
                Wallet & <span className="bg-gradient-to-r from-cyan-400 to-violet-500 bg-clip-text text-transparent">Finances</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Deposit cash using eSewa/Khalti QR, request payouts, and check logs</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Left Column forms */}
              <div className="lg:col-span-2 space-y-8">
                
                {/* Deposit Form */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8">
                  <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6">Deposit Funds</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    
                    {/* Payment QR Code info */}
                    <div className="space-y-4">
                      <p className="text-xs text-slate-500 font-bold uppercase">1. Select Payment gateway & scan</p>
                      
                      <div className="grid grid-cols-2 gap-3 bg-slate-950 p-1.5 rounded-xl border border-slate-850">
                        <button
                          type="button"
                          onClick={() => setDepositMethod('eSewa')}
                          className={`py-2 rounded-lg font-bold text-xs uppercase transition-all ${
                            depositMethod === 'eSewa' ? 'bg-cyan-500 text-black' : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          eSewa QR
                        </button>
                        <button
                          type="button"
                          onClick={() => setDepositMethod('Khalti')}
                          className={`py-2 rounded-lg font-bold text-xs uppercase transition-all ${
                            depositMethod === 'Khalti' ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          Khalti QR
                        </button>
                      </div>

                      {/* Display configured QR from admin settings */}
                      <div className="bg-slate-950 p-4 rounded-2xl border border-slate-850 flex flex-col items-center justify-center text-center">
                        <img
                          src={depositMethod === 'eSewa' ? (adminConfig?.esewaQrUrl) : (adminConfig?.khaltiQrUrl)}
                          alt="Payment QR"
                          className="w-40 h-40 object-cover rounded-xl border border-slate-800 shadow-md mb-3"
                        />
                        <p className="text-[10px] text-slate-500 uppercase">Registered Mobile</p>
                        <p className="text-sm font-black text-white">
                          {depositMethod === 'eSewa' ? (adminConfig?.esewaPhone) : (adminConfig?.khaltiPhone)}
                        </p>
                      </div>
                    </div>

                    {/* Deposit Form Submit fields */}
                    <form onSubmit={handleDepositSubmit} className="space-y-4">
                      <p className="text-xs text-slate-500 font-bold uppercase">2. Fill Verification Form</p>
                      
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Deposit Amount (Rs.)</label>
                        <input
                          type="number"
                          required
                          min={adminConfig?.minDeposit || 10}
                          value={depositAmount}
                          onChange={(e) => setDepositAmount(Number(e.target.value))}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        />
                        <p className="text-[10px] text-slate-500 mt-1">Min deposit amount is Rs. {adminConfig?.minDeposit || 10}</p>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Transaction ID / TXN</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. TXN23984712"
                          value={depositTxnId}
                          onChange={(e) => setDepositTxnId(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm uppercase placeholder-slate-650"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Mock Screenshot URL (Optional)</label>
                        <input
                          type="text"
                          placeholder="Paste image link or leave blank"
                          value={depositScreenshot}
                          onChange={(e) => setDepositScreenshot(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-xs placeholder-slate-650"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold py-3 px-4 rounded-xl text-sm shadow-md"
                      >
                        Submit Deposit for Approval
                      </button>
                    </form>

                  </div>
                </div>

                {/* Withdraw Form */}
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8">
                  <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6">Request Withdrawal</h3>
                  
                  <form onSubmit={handleWithdrawSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 tracking-wider mb-2 uppercase">Payment Gateway</label>
                        <select
                          value={withdrawMethod}
                          onChange={(e) => setWithdrawMethod(e.target.value as 'eSewa' | 'Khalti')}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        >
                          <option value="eSewa">eSewa Wallet</option>
                          <option value="Khalti">Khalti Wallet</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-400 tracking-wider mb-2 uppercase">Withdraw Amount (Rs.)</label>
                        <input
                          type="number"
                          required
                          min={adminConfig?.minWithdraw || 50}
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        />
                        <p className="text-[10px] text-slate-500 mt-1">Min payout limit: Rs. {adminConfig?.minWithdraw || 50}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-400 tracking-wider mb-2 uppercase">Account Holder Phone</label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. 9841XXXXXX"
                          value={withdrawPhone}
                          onChange={(e) => setWithdrawPhone(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-400 tracking-wider mb-2 uppercase">Account Holder Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Ram Prasad Shrestha"
                          value={withdrawName}
                          onChange={(e) => setWithdrawName(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold py-3 px-4 rounded-xl text-sm"
                    >
                      Process Instant Cashout
                    </button>
                  </form>
                </div>

              </div>

              {/* Transaction Logs */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8">
                <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6">Financial History</h3>
                
                <div className="space-y-4 max-h-[600px] overflow-y-auto pr-1">
                  {userTransactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="p-3 bg-slate-950 border border-slate-850 rounded-2xl flex flex-col justify-between"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="text-xs font-bold text-white uppercase tracking-wider">
                            {tx.type === 'deposit' ? '💰 Deposit' : tx.type === 'withdrawal' ? '💸 Cashout' : tx.type === 'referral' ? '🔗 Referral' : '⚔️ Tournament Fee'}
                          </p>
                          <p className="text-[10px] text-slate-500">{new Date(tx.createdAt).toLocaleString()}</p>
                        </div>
                        
                        <span className={`text-[9px] uppercase font-black px-2 py-0.5 rounded ${
                          tx.status === 'approved' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' : tx.status === 'rejected' ? 'bg-red-950 text-red-400 border border-red-800/40' : 'bg-amber-950 text-amber-400 border border-amber-800/40'
                        }`}>
                          {tx.status}
                        </span>
                      </div>

                      <div className="flex justify-between items-end pt-1 border-t border-slate-900 text-xs">
                        <span className="text-slate-500">Method: {tx.method}</span>
                        <span className={`font-extrabold ${tx.type === 'deposit' || tx.type === 'referral' || tx.type === 'tournament_win' || tx.type === 'daily_spin' || tx.type === 'daily_login' ? 'text-emerald-400' : 'text-rose-500'}`}>
                          {tx.type === 'deposit' || tx.type === 'referral' || tx.type === 'tournament_win' || tx.type === 'daily_spin' || tx.type === 'daily_login' ? '+' : '-'} Rs. {tx.amount}
                        </span>
                      </div>

                      {tx.transactionId && (
                        <p className="text-[9px] text-slate-500 mt-2 font-mono">TXN: {tx.transactionId}</p>
                      )}
                    </div>
                  ))}

                  {userTransactions.length === 0 && (
                    <p className="text-xs text-slate-500 text-center py-10">No transaction logs recorded yet.</p>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Refer & Earn Tab */}
        {activeTab === 'referrals' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Users className="w-7 h-7 text-cyan-400" />
                Refer & <span className="bg-gradient-to-r from-cyan-400 to-violet-500 bg-clip-text text-transparent">Earn</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Get rewarded with Rs. 2.50 cash for every gaming referral you refer</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Left Column Stats */}
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6">
                
                {/* Promo Banner and Code */}
                <div className="bg-gradient-to-tr from-cyan-950/60 via-slate-950 to-violet-950/60 border border-violet-850 p-6 rounded-2xl flex flex-col md:flex-row justify-between items-center gap-6">
                  <div className="space-y-2 text-center md:text-left">
                    <h3 className="font-extrabold text-white text-lg">Invite Friends & Level Up</h3>
                    <p className="text-xs text-slate-400 max-w-sm">
                      Copy your link or send code to earn Rs. 2.50 for every verified registration. Cash credits immediately.
                    </p>
                  </div>

                  <div className="space-y-3 w-full md:w-auto">
                    <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl text-center">
                      <p className="text-[9px] text-slate-500 uppercase font-black">Your Referral Code</p>
                      <p className="text-lg font-black text-cyan-400 tracking-wider mt-1">{currentUser.referralCode}</p>
                    </div>

                    <button
                      onClick={copyReferralLink}
                      className="w-full py-2.5 px-4 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Copy className="w-4 h-4" />
                      Copy Referral Link
                    </button>
                  </div>
                </div>

                {/* Referral leaderboard */}
                <div>
                  <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4">Referral Analytics</h3>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850">
                      <p className="text-xs text-slate-500 font-semibold uppercase">Total Invites</p>
                      <p className="text-xl font-extrabold text-white mt-1">{currentUser.referralsCount}</p>
                    </div>
                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850">
                      <p className="text-xs text-slate-500 font-semibold uppercase">Earnings Rate</p>
                      <p className="text-xl font-extrabold text-emerald-400 mt-1">Rs. 2.50</p>
                    </div>
                    <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-850">
                      <p className="text-xs text-slate-500 font-semibold uppercase">Ref. Wallet Cash</p>
                      <p className="text-xl font-extrabold text-cyan-400 mt-1">Rs. {currentUser.referralEarnings}</p>
                    </div>
                  </div>
                </div>

                {/* Invite list */}
                <div>
                  <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4">Your Reffered Friends</h3>
                  
                  <div className="space-y-2">
                    {users
                      .filter(u => u.referredBy === currentUser.id)
                      .map((u, idx) => (
                        <div key={idx} className="flex justify-between items-center p-3 bg-slate-950 rounded-xl border border-slate-850">
                          <div className="flex items-center gap-3">
                            <img src={u.avatarUrl} alt="Avatar" className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800" />
                            <div>
                              <p className="text-xs font-bold text-white">{u.username}</p>
                              <p className="text-[9px] text-slate-500">Joined {new Date(u.createdAt).toLocaleDateString()}</p>
                            </div>
                          </div>
                          <span className="text-[10px] text-emerald-400 font-black uppercase bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-800/30">
                            + Rs. 2.50
                          </span>
                        </div>
                      ))}

                    {users.filter(u => u.referredBy === currentUser.id).length === 0 && (
                      <p className="text-xs text-slate-500 text-center py-6">You haven't referred anyone yet. Share your code to start!</p>
                    )}
                  </div>
                </div>

              </div>

              {/* Side Tips */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6">
                <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">How to refer</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-violet-950 border border-violet-800 text-violet-400 flex items-center justify-center text-xs font-black">1</span>
                    <p className="text-xs text-slate-400">Share your custom referral code or link with other gamers.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-violet-950 border border-violet-800 text-violet-400 flex items-center justify-center text-xs font-black">2</span>
                    <p className="text-xs text-slate-400">Your friend signs up using your code on the registration page.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-violet-950 border border-violet-800 text-violet-400 flex items-center justify-center text-xs font-black">3</span>
                    <p className="text-xs text-slate-400">You instantly get credited Rs. 2.50 wallet cash directly.</p>
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Spin & Win Tab */}
        {activeTab === 'spin' && (
          <SpinWheel
            currentUser={currentUser}
            onUpdateUser={onUpdateUser}
            notify={notify}
          />
        )}

        {/* Alerts / Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Bell className="w-7 h-7 text-cyan-400" />
                Alerts & <span className="bg-gradient-to-r from-cyan-400 to-violet-500 bg-clip-text text-transparent">Notifications</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Keep track of deposit approvals, withdrawal receipts, and tournament lobby announcements</p>
            </div>

            <div className="space-y-4 max-w-4xl">
              {/* Show updates from transactions status change */}
              {userTransactions.map((tx) => (
                <div
                  key={tx.id}
                  className={`p-4 rounded-2xl border flex gap-4 items-start ${
                    tx.status === 'approved' 
                      ? 'bg-emerald-950/20 border-emerald-800/40 text-emerald-350' 
                      : tx.status === 'rejected' 
                      ? 'bg-rose-950/20 border-rose-800/40 text-rose-300' 
                      : 'bg-amber-950/20 border-amber-800/40 text-amber-300'
                  }`}
                >
                  <div className="p-2 bg-slate-900 border border-slate-800 rounded-xl">
                    {tx.status === 'approved' ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400" />
                    ) : tx.status === 'rejected' ? (
                      <XCircle className="w-5 h-5 text-rose-500" />
                    ) : (
                      <Clock className="w-5 h-5 text-amber-500" />
                    )}
                  </div>

                  <div>
                    <h4 className="font-extrabold text-sm text-white">
                      {tx.type === 'deposit' ? 'Deposit Request Updates' : 'Withdrawal Request Updates'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Your request of <span className="font-bold text-white">Rs. {tx.amount}</span> via {tx.method} is currently{' '}
                      <span className="font-bold underline">{tx.status}</span>.
                    </p>
                    <p className="text-[10px] text-slate-500 mt-2 font-mono">
                      Timestamp: {new Date(tx.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))}

              {userTransactions.length === 0 && (
                <div className="text-center py-20 bg-slate-900 border border-slate-800 rounded-3xl">
                  <p className="text-slate-500 font-bold text-sm">No match or transaction alerts found.</p>
                </div>
              )}
            </div>
          </div>
        )}

      </main>

      {/* 3. JOINING TOURNAMENT CONFIRMATION MODAL */}
      {isJoiningModalOpen && selectedTour && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setIsJoiningModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold"
            >
              &times;
            </button>

            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-2">Confirm Slot Registration</h3>
            <p className="text-xs text-slate-400 mb-6">
              You are about to register for <span className="text-white font-bold">{selectedTour.title}</span>.
            </p>

            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-850 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-semibold uppercase">Prize Pool</span>
                  <span className="text-emerald-400 font-extrabold">Rs. {selectedTour.prizePool}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-semibold uppercase">Entry Fee</span>
                  <span className="text-white font-extrabold">Rs. {selectedTour.entryFee}</span>
                </div>
                <div className="flex justify-between border-t border-slate-900 pt-2 font-bold">
                  <span className="text-slate-400">Your Balance</span>
                  <span className="text-cyan-400">Rs. {currentUser.walletBalance}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Enter Your {selectedTour.game} Nickname / Gamer ID
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FF_Deadpool_007"
                  value={joinNickname}
                  onChange={(e) => setJoinNickname(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl py-3 px-4 text-white text-sm"
                />
                <p className="text-[10px] text-slate-500 mt-1">This ID will be used for auto matching and room lobbies.</p>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  onClick={confirmJoinTournament}
                  className="flex-1 bg-gradient-to-r from-cyan-500 to-violet-600 text-white font-bold py-3 px-4 rounded-xl text-sm"
                >
                  Pay & Register (Rs. {selectedTour.entryFee})
                </button>
                <button
                  onClick={() => setIsJoiningModalOpen(false)}
                  className="px-5 py-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl text-sm font-bold text-slate-400"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    
{/* Mobile Bottom Navigation - keeps all existing features intact */}
<div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-950 border-t border-slate-800 z-50 flex justify-around py-3">
  <button onClick={() => setActiveTab('notifications')} className="flex flex-col items-center text-xs">
    <Bell className="w-5 h-5" />
    <span>Home</span>
  </button>
  <button onClick={() => setActiveTab('tournaments')} className="flex flex-col items-center text-xs">
    <Trophy className="w-5 h-5" />
    <span>Match</span>
  </button>
  <button onClick={() => setActiveTab('wallet')} className="flex flex-col items-center text-xs">
    <Wallet className="w-5 h-5" />
    <span>Wallet</span>
  </button>
  <button onClick={() => setActiveTab('profile')} className="flex flex-col items-center text-xs">
    <UserIcon className="w-5 h-5" />
    <span>Profile</span>
  </button>
</div>

</div>
  );
};
