import React, { useState, useEffect } from 'react';
import { 
  User, Tournament, Transaction, AdminConfig, FAQItem, Announcement, ActivityLog,
  getUsers, saveUsers, getTournaments, saveTournaments, 
  getTransactions, saveTransactions, getConfig, saveConfig,
  getFAQs, saveFAQs, getAnnouncements, saveAnnouncements, getLogs, addLog 
} from '../utils/db';
import { 
  ShieldAlert, Users, Wallet, Trophy, Settings,
  CheckCircle, XCircle, Search, Edit3, Trash2, 
  Plus, Award, Lock, FileText, LayoutDashboard, Volume2
} from 'lucide-react';

interface AdminPanelProps {
  currentUser: User;
  onLogout: () => void;
  notify: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  onLogout,
  notify,
}) => {
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Database states
  const [users, setUsers] = useState<User[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [config, setConfig] = useState<AdminConfig | null>(null);
  const [systemLogs, setSystemLogs] = useState<ActivityLog[]>([]);

  // Search & Filters
  const [userSearch, setUserSearch] = useState('');

  // Edit User Modal
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editWalletBal, setEditWalletBal] = useState<number>(0);
  const [editCoinsBal, setEditCoinsBal] = useState<number>(0);

  // Tournament Form
  const [isTourModalOpen, setIsTourModalOpen] = useState(false);
  const [tourFormMode, setTourFormMode] = useState<'create' | 'edit'>('create');
  const [selectedTourId, setSelectedTourId] = useState<string | null>(null);
  
  const [tourTitle, setTourTitle] = useState('');
  const [tourGame, setTourGame] = useState<'Free Fire' | 'PUBG Mobile' | 'Mobile Legends' | 'eFootball' | 'Other'>('Free Fire');
  const [tourFormat, setTourFormat] = useState<'Solo' | 'Duo' | 'Squad'>('Solo');
  const [tourBracket, setTourBracket] = useState<'Single Elimination' | 'Double Elimination' | 'Round Robin'>('Single Elimination');
  const [tourEntryFee, setTourEntryFee] = useState<number>(0);
  const [tourPrizePool, setTourPrizePool] = useState<number>(500);
  const [tourSlots, setTourSlots] = useState<number>(32);
  const [tourStartTime, setTourStartTime] = useState('');
  const [tourRules, setTourRules] = useState<string>('');
  const [tourBanner, setTourBanner] = useState('');

  // Declare Winners Modal
  const [publishTour, setPublishTour] = useState<Tournament | null>(null);
  const [winner1Name, setWinner1Name] = useState('');
  const [winner2Name, setWinner2Name] = useState('');
  const [winner3Name, setWinner3Name] = useState('');
  const [winner1Prize, setWinner1Prize] = useState<number>(0);
  const [winner2Prize, setWinner2Prize] = useState<number>(0);
  const [winner3Prize, setWinner3Prize] = useState<number>(0);
  const [roomIdInput, setRoomIdInput] = useState('');
  const [roomPassInput, setRoomPassInput] = useState('');

  // Configuration Form
  const [esewaQr, setEsewaQr] = useState('');
  const [esewaNum, setEsewaNum] = useState('');
  const [khaltiQr, setKhaltiQr] = useState('');
  const [khaltiNum, setKhaltiNum] = useState('');
  const [minDep, setMinDep] = useState<number>(10);
  const [minWdr, setMinWdr] = useState<number>(50);

  // FAQ Form
  const [faqQuestion, setFaqQuestion] = useState('');
  const [faqAnswer, setFaqAnswer] = useState('');

  // Announcement Form
  const [annTitle, setAnnTitle] = useState('');
  const [annContent, setAnnContent] = useState('');
  const [annType, setAnnType] = useState<'info' | 'warning' | 'success'>('info');

  const loadAllData = () => {
    setUsers(getUsers());
    setTournaments(getTournaments());
    setTransactions(getTransactions());
    setFaqs(getFAQs());
    setAnnouncements(getAnnouncements());
    const c = getConfig();
    setConfig(c);
    setSystemLogs(getLogs());
    
    if (c) {
      setEsewaQr(c.esewaQrUrl);
      setEsewaNum(c.esewaPhone);
      setKhaltiQr(c.khaltiQrUrl);
      setKhaltiNum(c.khaltiPhone);
      setMinDep(c.minDeposit);
      setMinWdr(c.minWithdraw);
    }
  };

  useEffect(() => {
    loadAllData();
    const interval = setInterval(loadAllData, 10000);
    return () => clearInterval(interval);
  }, []);

  // Overview Stats
  const activeUsers = users.filter(u => u.status === 'active').length;
  
  const totalApprovedDeposits = transactions
    .filter(t => t.type === 'deposit' && t.status === 'approved')
    .reduce((acc, t) => acc + t.amount, 0);

  const totalApprovedWithdrawals = transactions
    .filter(t => t.type === 'withdrawal' && t.status === 'approved')
    .reduce((acc, t) => acc + t.amount, 0);

  // Revenue analytics (Entry fees collected minus prize distributed)
  const entryFeesCollected = transactions
    .filter(t => t.type === 'tournament_entry' && t.status === 'approved')
    .reduce((acc, t) => acc + t.amount, 0);

  const prizeDistributed = tournaments
    .filter(t => t.status === 'completed')
    .reduce((acc, t) => {
      const winSum = t.winners?.reduce((sum, w) => sum + w.prize, 0) || 0;
      return acc + winSum;
    }, 0);

  const estimatedProfit = entryFeesCollected - prizeDistributed;

  // Toggle user ban status
  const handleToggleBan = (user: User) => {
    if (user.id === currentUser.id) {
      notify('Cannot ban yourself!', 'error');
      return;
    }

    const allUsers = getUsers();
    const targetIdx = allUsers.findIndex(u => u.id === user.id);
    if (targetIdx === -1) return;

    const currentStatus = allUsers[targetIdx].status;
    const newStatus = currentStatus === 'active' ? 'banned' : 'active';
    
    allUsers[targetIdx].status = newStatus;
    saveUsers(allUsers);
    addLog(currentUser.id, currentUser.username, `Admin ${newStatus}ned user ${user.username}`);
    notify(`User ${user.username} has been ${newStatus}ned successfully!`, 'success');
    loadAllData();
  };

  // Edit user wallet & bonus balance
  const handleEditUserBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    const allUsers = getUsers();
    const uIdx = allUsers.findIndex(u => u.id === editingUser.id);
    if (uIdx === -1) return;

    allUsers[uIdx].walletBalance = editWalletBal;
    allUsers[uIdx].bonusCoins = editCoinsBal;
    
    saveUsers(allUsers);
    addLog(currentUser.id, currentUser.username, `Admin updated ${editingUser.username} balances: Rs. ${editWalletBal}, Coins ${editCoinsBal}`);
    notify(`Balances updated for ${editingUser.username}`, 'success');
    setEditingUser(null);
    loadAllData();
  };

  // Approve Deposit Request
  const handleApproveDeposit = (tx: Transaction) => {
    const allUsers = getUsers();
    const userIndex = allUsers.findIndex(u => u.id === tx.userId);
    if (userIndex === -1) {
      notify('User not found. Cannot credit deposit.', 'error');
      return;
    }

    // Set transaction to approved
    const txs = getTransactions();
    const txIdx = txs.findIndex(t => t.id === tx.id);
    if (txIdx === -1) return;

    txs[txIdx].status = 'approved';
    saveTransactions(txs);

    // Credit User Wallet
    allUsers[userIndex].walletBalance = Number((allUsers[userIndex].walletBalance + tx.amount).toFixed(2));
    
    // Add badge if total deposits reach 500
    const userDepositsTotal = txs
      .filter(t => t.userId === tx.userId && t.type === 'deposit' && t.status === 'approved')
      .reduce((sum, t) => sum + t.amount, 0);

    if (userDepositsTotal >= 500 && !allUsers[userIndex].badges.includes('Wallet Wealthy')) {
      allUsers[userIndex].badges.push('Wallet Wealthy');
    }

    saveUsers(allUsers);
    addLog(currentUser.id, currentUser.username, `Approved Rs. ${tx.amount} deposit for ${tx.username}`);
    notify(`Deposit of Rs. ${tx.amount} approved for ${tx.username}!`, 'success');
    loadAllData();
  };

  // Reject Deposit Request
  const handleRejectDeposit = (tx: Transaction) => {
    const txs = getTransactions();
    const txIdx = txs.findIndex(t => t.id === tx.id);
    if (txIdx === -1) return;

    txs[txIdx].status = 'rejected';
    saveTransactions(txs);

    addLog(currentUser.id, currentUser.username, `Rejected Rs. ${tx.amount} deposit request from ${tx.username}`);
    notify(`Deposit request of Rs. ${tx.amount} rejected.`, 'info');
    loadAllData();
  };

  // Approve Withdrawal Request
  const handleApproveWithdrawal = (tx: Transaction) => {
    const txs = getTransactions();
    const txIdx = txs.findIndex(t => t.id === tx.id);
    if (txIdx === -1) return;

    txs[txIdx].status = 'approved';
    saveTransactions(txs);

    addLog(currentUser.id, currentUser.username, `Approved withdrawal of Rs. ${tx.amount} to ${tx.accountNo} for ${tx.username}`);
    notify(`Withdrawal request of Rs. ${tx.amount} marked as processed!`, 'success');
    loadAllData();
  };

  // Reject Withdrawal Request
  const handleRejectWithdrawal = (tx: Transaction) => {
    const txs = getTransactions();
    const txIdx = txs.findIndex(t => t.id === tx.id);
    if (txIdx === -1) return;

    txs[txIdx].status = 'rejected';
    saveTransactions(txs);

    // Return the locked amount back to user's wallet
    const allUsers = getUsers();
    const uIdx = allUsers.findIndex(u => u.id === tx.userId);
    if (uIdx !== -1) {
      allUsers[uIdx].walletBalance = Number((allUsers[uIdx].walletBalance + tx.amount).toFixed(2));
      saveUsers(allUsers);
    }

    addLog(currentUser.id, currentUser.username, `Rejected withdrawal of Rs. ${tx.amount} for ${tx.username} (funds returned)`);
    notify(`Withdrawal request rejected. Funds returned to ${tx.username}'s wallet.`, 'info');
    loadAllData();
  };

  // Save Settings Config
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!config) return;

    const newConf: AdminConfig = {
      ...config,
      esewaQrUrl: esewaQr,
      esewaPhone: esewaNum,
      khaltiQrUrl: khaltiQr,
      khaltiPhone: khaltiNum,
      minDeposit: minDep,
      minWithdraw: minWdr
    };

    saveConfig(newConf);
    addLog(currentUser.id, currentUser.username, 'Updated application global payment settings');
    notify('Settings updated successfully!', 'success');
    loadAllData();
  };

  // Tournament Create/Edit Form Submission
  const handleTournamentSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!tourTitle || !tourStartTime) {
      notify('Tournament title and start time are required.', 'error');
      return;
    }

    const allTours = getTournaments();
    const rulesArray = tourRules.split('\n').filter(r => r.trim().length > 0);

    const banner = tourBanner.trim() || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800';

    if (tourFormMode === 'create') {
      const newTour: Tournament = {
        id: 'tour_' + Date.now(),
        title: tourTitle,
        game: tourGame,
        format: tourFormat,
        bracketType: tourBracket,
        entryFee: tourEntryFee,
        prizePool: tourPrizePool,
        totalSlots: tourSlots,
        registeredPlayers: [],
        participants: [],
        status: 'upcoming',
        startTime: new Date(tourStartTime).toISOString(),
        rules: rulesArray,
        bannerUrl: banner
      };

      allTours.unshift(newTour);
      addLog(currentUser.id, currentUser.username, `Created tournament: ${tourTitle}`);
      notify('Tournament created successfully!', 'success');
    } else {
      // Edit Mode
      if (!selectedTourId) return;
      const tIdx = allTours.findIndex(t => t.id === selectedTourId);
      if (tIdx === -1) return;

      const existing = allTours[tIdx];
      allTours[tIdx] = {
        ...existing,
        title: tourTitle,
        game: tourGame,
        format: tourFormat,
        bracketType: tourBracket,
        entryFee: tourEntryFee,
        prizePool: tourPrizePool,
        totalSlots: tourSlots,
        startTime: new Date(tourStartTime).toISOString(),
        rules: rulesArray,
        bannerUrl: banner
      };
      addLog(currentUser.id, currentUser.username, `Edited tournament: ${tourTitle}`);
      notify('Tournament updated successfully!', 'success');
    }

    saveTournaments(allTours);
    setIsTourModalOpen(false);
    
    // Clear form
    setTourTitle('');
    setTourEntryFee(0);
    setTourPrizePool(500);
    setTourSlots(32);
    setTourStartTime('');
    setTourRules('');
    setTourBanner('');
    loadAllData();
  };

  const handleEditTournament = (tour: Tournament) => {
    setTourFormMode('edit');
    setSelectedTourId(tour.id);
    setTourTitle(tour.title);
    setTourGame(tour.game);
    setTourFormat(tour.format);
    setTourBracket(tour.bracketType);
    setTourEntryFee(tour.entryFee);
    setTourPrizePool(tour.prizePool);
    setTourSlots(tour.totalSlots);
    
    // Convert to input local datetime format
    const localTime = new Date(tour.startTime).toISOString().slice(0, 16);
    setTourStartTime(localTime);
    setTourRules(tour.rules.join('\n'));
    setTourBanner(tour.bannerUrl);

    setIsTourModalOpen(true);
  };

  const handleDeleteTournament = (id: string) => {
    if (!window.confirm('Are you sure you want to delete this tournament?')) return;
    const allTours = getTournaments();
    const filtered = allTours.filter(t => t.id !== id);
    saveTournaments(filtered);
    addLog(currentUser.id, currentUser.username, `Deleted tournament ID: ${id}`);
    notify('Tournament deleted successfully.', 'success');
    loadAllData();
  };

  // Publish / Declare Tournament Winners & Lobbies
  const handleUpdateLobbyAndStatus = (tour: Tournament, action: 'start' | 'update_room') => {
    const allTours = getTournaments();
    const tIdx = allTours.findIndex(t => t.id === tour.id);
    if (tIdx === -1) return;

    if (action === 'start') {
      allTours[tIdx].status = 'ongoing';
      notify('Tournament status updated to Live / Ongoing!', 'success');
    }

    if (roomIdInput.trim()) {
      allTours[tIdx].roomDetails = {
        roomId: roomIdInput.trim(),
        roomPassword: roomPassInput.trim()
      };
      notify('Room code details updated for participants!', 'success');
    }

    saveTournaments(allTours);
    setRoomIdInput('');
    setRoomPassInput('');
    loadAllData();
  };

  const handlePublishResults = (e: React.FormEvent) => {
    e.preventDefault();
    if (!publishTour) return;

    const allTours = getTournaments();
    const tourIndex = allTours.findIndex(t => t.id === publishTour.id);
    if (tourIndex === -1) return;

    // Set tournament completed
    const targetTour = { ...allTours[tourIndex] };
    targetTour.status = 'completed';

    const winnersList: Array<{ rank: number; username: string; prize: number }> = [];

    // Credit User Wallet for Rank 1
    const allUsers = getUsers();
    if (winner1Name.trim() && winner1Prize > 0) {
      winnersList.push({ rank: 1, username: winner1Name.trim(), prize: winner1Prize });
      const uIndex = allUsers.findIndex(u => u.username.toLowerCase() === winner1Name.trim().toLowerCase());
      if (uIndex !== -1) {
        allUsers[uIndex].walletBalance = Number((allUsers[uIndex].walletBalance + winner1Prize).toFixed(2));
        
        // Add champion badge
        if (!allUsers[uIndex].badges.includes('Champion')) {
          allUsers[uIndex].badges.push('Champion');
        }
        
        // Log transaction
        const txs = getTransactions();
        txs.unshift({
          id: 'tx_win1_' + Date.now(),
          userId: allUsers[uIndex].id,
          username: allUsers[uIndex].username,
          type: 'tournament_win',
          amount: winner1Prize,
          method: 'System',
          status: 'approved',
          createdAt: new Date().toISOString()
        });
        saveTransactions(txs);
      }
    }

    // Credit User Wallet for Rank 2
    if (winner2Name.trim() && winner2Prize > 0) {
      winnersList.push({ rank: 2, username: winner2Name.trim(), prize: winner2Prize });
      const uIndex = allUsers.findIndex(u => u.username.toLowerCase() === winner2Name.trim().toLowerCase());
      if (uIndex !== -1) {
        allUsers[uIndex].walletBalance = Number((allUsers[uIndex].walletBalance + winner2Prize).toFixed(2));
        // Log transaction
        const txs = getTransactions();
        txs.unshift({
          id: 'tx_win2_' + Date.now(),
          userId: allUsers[uIndex].id,
          username: allUsers[uIndex].username,
          type: 'tournament_win',
          amount: winner2Prize,
          method: 'System',
          status: 'approved',
          createdAt: new Date().toISOString()
        });
        saveTransactions(txs);
      }
    }

    // Credit User Wallet for Rank 3
    if (winner3Name.trim() && winner3Prize > 0) {
      winnersList.push({ rank: 3, username: winner3Name.trim(), prize: winner3Prize });
      const uIndex = allUsers.findIndex(u => u.username.toLowerCase() === winner3Name.trim().toLowerCase());
      if (uIndex !== -1) {
        allUsers[uIndex].walletBalance = Number((allUsers[uIndex].walletBalance + winner3Prize).toFixed(2));
        // Log transaction
        const txs = getTransactions();
        txs.unshift({
          id: 'tx_win3_' + Date.now(),
          userId: allUsers[uIndex].id,
          username: allUsers[uIndex].username,
          type: 'tournament_win',
          amount: winner3Prize,
          method: 'System',
          status: 'approved',
          createdAt: new Date().toISOString()
        });
        saveTransactions(txs);
      }
    }

    targetTour.winners = winnersList;
    allTours[tourIndex] = targetTour;
    saveTournaments(allTours);
    saveUsers(allUsers);

    addLog(currentUser.id, currentUser.username, `Published results for tournament: ${publishTour.title}`);
    notify('Tournament results published and prizes disbursed successfully!', 'success');

    // Reset fields
    setPublishTour(null);
    setWinner1Name('');
    setWinner2Name('');
    setWinner3Name('');
    setWinner1Prize(0);
    setWinner2Prize(0);
    setWinner3Prize(0);
    loadAllData();
  };

  // Add FAQ Item
  const handleAddFaq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!faqQuestion || !faqAnswer) return;

    const allFaqs = getFAQs();
    allFaqs.push({
      id: 'faq_' + Date.now(),
      question: faqQuestion,
      answer: faqAnswer
    });
    saveFAQs(allFaqs);
    addLog(currentUser.id, currentUser.username, `Created FAQ: ${faqQuestion}`);
    notify('FAQ item added successfully!', 'success');
    setFaqQuestion('');
    setFaqAnswer('');
    loadAllData();
  };

  const handleDeleteFaq = (id: string) => {
    const allFaqs = getFAQs();
    saveFAQs(allFaqs.filter(f => f.id !== id));
    notify('FAQ item deleted.', 'info');
    loadAllData();
  };

  // Add Announcement
  const handleAddAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle || !annContent) return;

    const allAnns = getAnnouncements();
    allAnns.unshift({
      id: 'ann_' + Date.now(),
      title: annTitle,
      content: annContent,
      type: annType,
      createdAt: new Date().toISOString()
    });
    saveAnnouncements(allAnns);
    addLog(currentUser.id, currentUser.username, `Created Announcement: ${annTitle}`);
    notify('Announcement broadcasted!', 'success');
    setAnnTitle('');
    setAnnContent('');
    loadAllData();
  };

  const handleDeleteAnnouncement = (id: string) => {
    const allAnns = getAnnouncements();
    saveAnnouncements(allAnns.filter(a => a.id !== id));
    notify('Announcement removed.', 'info');
    loadAllData();
  };

  // Filtered Users list
  const filteredUsers = users.filter(
    u => 
      u.username.toLowerCase().includes(userSearch.toLowerCase()) || 
      u.email.toLowerCase().includes(userSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row font-sans">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-900 border-r border-slate-800 p-6 flex flex-col justify-between flex-shrink-0">
        
        <div>
          <div className="flex items-center gap-3 mb-8">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-red-500 to-amber-600 shadow-[0_0_15px_rgba(220,38,38,0.4)] flex items-center justify-center font-black text-white text-base">
              N
            </div>
            <div>
              <h2 className="text-sm font-black tracking-wider text-white">NIMZ BATTLE</h2>
              <span className="text-[10px] uppercase font-bold text-red-500 tracking-widest">Admin Desk</span>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-red-950/20 rounded-2xl border border-red-800/20 mb-8">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
            <p className="text-xs font-bold text-red-400">Authenticated Session</p>
          </div>

          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'overview' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              Overview Stats
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'users' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Users className="w-5 h-5" />
              User Control
            </button>

            <button
              onClick={() => setActiveTab('wallet')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center justify-between cursor-pointer ${
                activeTab === 'wallet' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <span className="flex items-center gap-3">
                <Wallet className="w-5 h-5" />
                Wallet Requests
              </span>
              {transactions.filter(t => t.status === 'pending').length > 0 && (
                <span className="w-5 h-5 bg-cyan-600 text-slate-950 rounded-full flex items-center justify-center text-[10px] font-black">
                  {transactions.filter(t => t.status === 'pending').length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('tournaments')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'tournaments' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Trophy className="w-5 h-5" />
              Tournaments
            </button>

            <button
              onClick={() => setActiveTab('config')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'config' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Settings className="w-5 h-5" />
              Gateway Settings
            </button>

            <button
              onClick={() => setActiveTab('content')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'content' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <Volume2 className="w-5 h-5" />
              Announcements / FAQs
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`w-full text-left py-3 px-4 rounded-xl font-bold text-sm transition-all flex items-center gap-3 cursor-pointer ${
                activeTab === 'logs' ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
              }`}
            >
              <FileText className="w-5 h-5" />
              Audit Logs
            </button>
          </nav>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-800">
          <button
            onClick={onLogout}
            className="w-full py-2.5 px-4 rounded-xl text-rose-500 hover:text-rose-450 hover:bg-rose-950/20 font-bold text-sm transition-all flex items-center gap-3 cursor-pointer"
          >
            <Lock className="w-5 h-5" />
            Exit Admin Area
          </button>
        </div>
      </aside>

      {/* Main Tab Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto max-w-7xl">
        
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                Management <span className="text-red-500">Overview</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Global platform metrics, users statistics, deposits and cash flow</p>
            </div>

            {/* Metric statistics Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <p className="text-xs text-slate-500 font-semibold uppercase">Total / Active Users</p>
                  <Users className="w-5 h-5 text-red-500" />
                </div>
                <p className="text-2xl font-black text-white">{users.length} <span className="text-xs font-medium text-slate-400">({activeUsers} Active)</span></p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <p className="text-xs text-slate-500 font-semibold uppercase">Approved Deposits</p>
                  <Wallet className="w-5 h-5 text-emerald-400" />
                </div>
                <p className="text-2xl font-black text-emerald-400">Rs. {totalApprovedDeposits}</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <p className="text-xs text-slate-500 font-semibold uppercase">Approved Cashouts</p>
                  <Wallet className="w-5 h-5 text-rose-500" />
                </div>
                <p className="text-2xl font-black text-rose-500">Rs. {totalApprovedWithdrawals}</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex justify-between items-center mb-3">
                  <p className="text-xs text-slate-500 font-semibold uppercase">Estimated Revenue</p>
                  <Trophy className="w-5 h-5 text-cyan-400" />
                </div>
                <p className={`text-2xl font-black ${estimatedProfit >= 0 ? 'text-cyan-400' : 'text-red-500'}`}>
                  Rs. {estimatedProfit}
                </p>
              </div>
            </div>

            {/* Quick Analytics & Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6">
                <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4">Latest Registered Users</h3>
                <div className="space-y-3">
                  {users.slice(-5).reverse().map((u) => (
                    <div key={u.id} className="p-3 bg-slate-950 rounded-xl border border-slate-850 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <img src={u.avatarUrl} alt="Avatar" className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800" />
                        <div>
                          <p className="text-xs font-bold text-white">{u.username}</p>
                          <p className="text-[10px] text-slate-500">{u.email}</p>
                        </div>
                      </div>

                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${
                        u.status === 'active' ? 'bg-emerald-950 text-emerald-400' : 'bg-red-950 text-red-400'
                      }`}>
                        {u.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4">System Actions</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Total Tournaments Created</span>
                      <span className="font-extrabold text-white">{tournaments.length}</span>
                    </div>
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Pending Wallet Actions</span>
                      <span className="font-extrabold text-white">
                        {transactions.filter(t => t.status === 'pending').length}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-red-950/20 border border-red-800/30 rounded-2xl">
                  <h4 className="text-xs font-bold text-red-400 flex items-center gap-1.5 mb-1">
                    <ShieldAlert className="w-4 h-4" />
                    Security Controls
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Audit logs are generated for all admin actions. Fraud transaction details will flag IPs.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* User Control Tab */}
        {activeTab === 'users' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                  User <span className="text-red-500">Directory</span>
                </h2>
                <p className="text-slate-400 text-xs mt-1">Search players, view balances, edit, or toggle ban status</p>
              </div>

              <div className="relative w-full sm:w-64">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  placeholder="Search user..."
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl py-2 pl-9 pr-4 text-white text-xs"
                />
              </div>
            </div>

            {/* Users Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-850">
                      <th className="py-4 px-6">User / Email</th>
                      <th className="py-4 px-6">Wallet Balance</th>
                      <th className="py-4 px-6">Bonus Coins</th>
                      <th className="py-4 px-6">Badges</th>
                      <th className="py-4 px-6">Status</th>
                      <th className="py-4 px-6 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 font-medium">
                    {filteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-850/30 transition-colors">
                        <td className="py-4 px-6 flex items-center gap-3">
                          <img src={u.avatarUrl} alt="Avatar" className="w-9 h-9 rounded-full bg-slate-950 border border-slate-800" />
                          <div>
                            <p className="font-bold text-white flex items-center gap-1.5">
                              {u.username}
                              {u.role === 'admin' && (
                                <span className="bg-red-950 border border-red-800 text-red-500 text-[9px] px-1.5 py-0.5 rounded font-black uppercase">
                                  Staff
                                </span>
                              )}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono">{u.email}</p>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-emerald-400 font-extrabold">Rs. {u.walletBalance}</td>
                        <td className="py-4 px-6 text-violet-400 font-extrabold">{u.bonusCoins} Coins</td>
                        <td className="py-4 px-6 text-slate-400 max-w-[150px] truncate">
                          {u.badges.join(', ') || 'None'}
                        </td>
                        <td className="py-4 px-6">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                            u.status === 'active' ? 'bg-emerald-950 text-emerald-400' : 'bg-red-950 text-red-400'
                          }`}>
                            {u.status}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-right space-x-2">
                          <button
                            onClick={() => {
                              setEditingUser(u);
                              setEditWalletBal(u.walletBalance);
                              setEditCoinsBal(u.bonusCoins);
                            }}
                            className="px-2.5 py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-cyan-400 font-bold hover:text-cyan-300 transition-colors cursor-pointer"
                          >
                            Adjust Balances
                          </button>
                          
                          <button
                            onClick={() => handleToggleBan(u)}
                            className={`px-2.5 py-1.5 rounded-lg font-bold transition-colors cursor-pointer ${
                              u.status === 'active' 
                                ? 'bg-red-950 hover:bg-red-900 border border-red-900/30 text-red-400' 
                                : 'bg-emerald-950 hover:bg-emerald-900 border border-emerald-900/30 text-emerald-450'
                            }`}
                          >
                            {u.status === 'active' ? 'Ban' : 'Unban'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Wallet Requests Tab */}
        {activeTab === 'wallet' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                Transaction <span className="text-red-500">Approvals</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Review pending eSewa/Khalti deposit screens and process withdrawals</p>
            </div>

            {/* Pending Requests List */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Deposit Requests */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6">
                <h3 className="text-base font-extrabold text-white uppercase tracking-wider">Pending Deposits</h3>
                
                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
                  {transactions
                    .filter(t => t.type === 'deposit' && t.status === 'pending')
                    .map((tx) => (
                      <div key={tx.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-850 space-y-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-xs font-bold text-white">{tx.username}</p>
                            <p className="text-[10px] text-slate-500">Method: {tx.method} | {new Date(tx.createdAt).toLocaleString()}</p>
                          </div>
                          <span className="text-sm font-black text-emerald-400">Rs. {tx.amount}</span>
                        </div>

                        <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-850 font-mono text-[10px] text-slate-400 space-y-1">
                          <p>TXN ID: <span className="text-white font-extrabold">{tx.transactionId}</span></p>
                          <p>Screen Verification URL:</p>
                          <a href={tx.screenshotUrl} target="_blank" rel="noreferrer" className="text-cyan-400 break-all select-all">{tx.screenshotUrl}</a>
                        </div>

                        <div className="flex gap-3">
                          <button
                            onClick={() => handleApproveDeposit(tx)}
                            className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Approve
                          </button>
                          <button
                            onClick={() => handleRejectDeposit(tx)}
                            className="flex-1 py-2 bg-red-950 hover:bg-red-900 text-red-400 border border-red-900/30 font-black rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <XCircle className="w-4 h-4" />
                            Reject
                          </button>
                        </div>
                      </div>
                    ))}

                  {transactions.filter(t => t.type === 'deposit' && t.status === 'pending').length === 0 && (
                    <p className="text-xs text-slate-500 text-center py-10">No pending deposits currently.</p>
                  )}
                </div>
              </div>

              {/* Withdrawal Requests */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6">
                <h3 className="text-base font-extrabold text-white uppercase tracking-wider">Pending Withdrawals</h3>
                
                <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
                  {transactions
                    .filter(t => t.type === 'withdrawal' && t.status === 'pending')
                    .map((tx) => (
                      <div key={tx.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-850 space-y-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-xs font-bold text-white">{tx.username}</p>
                            <p className="text-[10px] text-slate-500">Method: {tx.method} | {new Date(tx.createdAt).toLocaleString()}</p>
                          </div>
                          <span className="text-sm font-black text-rose-500">Rs. {tx.amount}</span>
                        </div>

                        <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-850 font-mono text-[10px] text-slate-400 space-y-1">
                          <p>Account Phone: <span className="text-white font-extrabold">{tx.accountNo}</span></p>
                          <p>Holder Name: <span className="text-white font-extrabold uppercase">{tx.accountName}</span></p>
                        </div>

                        <div className="flex gap-3">
                          <button
                            onClick={() => handleApproveWithdrawal(tx)}
                            className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <CheckCircle className="w-4 h-4" />
                            Confirm Paid
                          </button>
                          <button
                            onClick={() => handleRejectWithdrawal(tx)}
                            className="flex-1 py-2 bg-red-950 hover:bg-red-900 text-red-400 border border-red-900/30 font-black rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <XCircle className="w-4 h-4" />
                            Deny & Refund
                          </button>
                        </div>
                      </div>
                    ))}

                  {transactions.filter(t => t.type === 'withdrawal' && t.status === 'pending').length === 0 && (
                    <p className="text-xs text-slate-500 text-center py-10">No pending withdrawal requests.</p>
                  )}
                </div>
              </div>

            </div>

            {/* Complete logs list */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4">Master Ledger History</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-850">
                      <th className="py-3 px-4">User</th>
                      <th className="py-3 px-4">Type</th>
                      <th className="py-3 px-4">Amount</th>
                      <th className="py-3 px-4">Method / TXN</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 font-medium">
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-850/20 transition-colors">
                        <td className="py-3 px-4 text-white font-bold">{tx.username}</td>
                        <td className="py-3 px-4 uppercase text-[10px] text-slate-400">{tx.type}</td>
                        <td className="py-3 px-4 text-white font-extrabold">Rs. {tx.amount}</td>
                        <td className="py-3 px-4 text-slate-500 font-mono">{tx.transactionId || tx.accountNo || 'System'}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                            tx.status === 'approved' ? 'bg-emerald-950 text-emerald-450' : tx.status === 'rejected' ? 'bg-red-950 text-red-400' : 'bg-amber-950 text-amber-450'
                          }`}>
                            {tx.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400">{new Date(tx.createdAt).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* Tournaments tab */}
        {activeTab === 'tournaments' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                  Esports <span className="text-red-500">Scheduler</span>
                </h2>
                <p className="text-slate-400 text-xs mt-1">Create tournaments, declare final match standings and edit rules</p>
              </div>

              <button
                onClick={() => {
                  setTourFormMode('create');
                  setTourTitle('');
                  setTourEntryFee(0);
                  setTourPrizePool(500);
                  setTourSlots(32);
                  setTourStartTime('');
                  setTourRules('');
                  setTourBanner('');
                  setIsTourModalOpen(true);
                }}
                className="px-5 py-3 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-black rounded-xl text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md"
              >
                <Plus className="w-4 h-4" />
                Build Tournament
              </button>
            </div>

            {/* Tournaments Grid List */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {tournaments.map((tour) => (
                <div key={tour.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-black uppercase bg-red-950 border border-red-800 text-rose-500 px-2 py-0.5 rounded">
                          {tour.game}
                        </span>
                        <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                          tour.status === 'upcoming' ? 'bg-cyan-950 text-cyan-400' : tour.status === 'ongoing' ? 'bg-red-950 text-rose-550' : 'bg-slate-950 text-slate-500'
                        }`}>
                          {tour.status}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-white mt-2">{tour.title}</h3>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditTournament(tour)}
                        className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-850 rounded-lg text-cyan-400 hover:text-cyan-300 transition-colors"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteTournament(tour.id)}
                        className="p-2 bg-slate-950 hover:bg-slate-800 border border-slate-850 rounded-lg text-rose-500 hover:text-rose-450 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs font-semibold">
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-850">
                      <p className="text-[10px] text-slate-500 uppercase">Prize Pool</p>
                      <p className="text-sm font-extrabold text-emerald-400">Rs. {tour.prizePool}</p>
                    </div>
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-850">
                      <p className="text-[10px] text-slate-500 uppercase">Registered Players</p>
                      <p className="text-sm font-extrabold text-white">{tour.registeredPlayers.length} / {tour.totalSlots}</p>
                    </div>
                  </div>

                  {/* Room details controller */}
                  {tour.status !== 'completed' && (
                    <div className="p-4 bg-slate-950 rounded-2xl border border-slate-850 space-y-4">
                      <p className="text-xs text-slate-400 font-bold">Room Codes & Lobbies</p>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="Room ID"
                          value={selectedTourId === tour.id ? roomIdInput : ''}
                          onChange={(e) => {
                            setSelectedTourId(tour.id);
                            setRoomIdInput(e.target.value);
                          }}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                        />
                        <input
                          type="text"
                          placeholder="Password"
                          value={selectedTourId === tour.id ? roomPassInput : ''}
                          onChange={(e) => {
                            setSelectedTourId(tour.id);
                            setRoomPassInput(e.target.value);
                          }}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                        />
                      </div>

                      <div className="flex gap-3">
                        <button
                          onClick={() => handleUpdateLobbyAndStatus(tour, 'update_room')}
                          className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg text-xs"
                        >
                          Update Room Details
                        </button>
                        {tour.status === 'upcoming' && (
                          <button
                            onClick={() => handleUpdateLobbyAndStatus(tour, 'start')}
                            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black rounded-lg text-xs uppercase"
                          >
                            Start Match
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Declare Winners Action */}
                  {tour.status !== 'completed' && (
                    <button
                      onClick={() => {
                        setPublishTour(tour);
                        setWinner1Prize(Math.round(tour.prizePool * 0.6));
                        setWinner2Prize(Math.round(tour.prizePool * 0.3));
                        setWinner3Prize(Math.round(tour.prizePool * 0.1));
                      }}
                      className="w-full py-3 bg-gradient-to-r from-red-650 to-amber-600 text-white font-bold rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                    >
                      <Award className="w-4 h-4" />
                      End Match & Publish Winners
                    </button>
                  )}

                  {/* Winners Standings display */}
                  {tour.status === 'completed' && tour.winners && (
                    <div className="p-3 bg-slate-950 border border-slate-850 rounded-2xl text-xs space-y-1">
                      <p className="text-amber-500 font-bold mb-1 flex items-center gap-1">🏆 Winner List</p>
                      {tour.winners.map((w, idx) => (
                        <div key={idx} className="flex justify-between items-center text-slate-400 font-medium">
                          <span>Rank #{w.rank}: <span className="text-white font-bold">{w.username}</span></span>
                          <span className="text-emerald-400">Rs. {w.prize}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Registered Nicknames list */}
                  <div className="p-3 bg-slate-950/60 border border-slate-850/60 rounded-2xl">
                    <p className="text-[10px] text-slate-500 font-bold uppercase mb-2">Registered Gamers Nicknames ({tour.participants.length})</p>
                    <div className="max-h-[100px] overflow-y-auto space-y-1">
                      {tour.participants.map((p, idx) => (
                        <div key={idx} className="flex justify-between items-center text-[10px] text-slate-400">
                          <span>{p.username}</span>
                          <span className="font-mono text-cyan-400">{p.gameNickname}</span>
                        </div>
                      ))}
                      {tour.participants.length === 0 && (
                        <p className="text-[10px] text-slate-600 italic">No registrations for this lobby yet.</p>
                      )}
                    </div>
                  </div>

                </div>
              ))}
            </div>
          </div>
        )}

        {/* Global configuration settings */}
        {activeTab === 'config' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                Gateway & <span className="text-red-500">Thresholds</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Configure physical payment QR URL, phone numbers, and min balances</p>
            </div>

            <form onSubmit={handleSaveConfig} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 max-w-2xl space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-xs font-black uppercase text-cyan-400 border-b border-slate-850 pb-2">eSewa Parameters</h3>
                  
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">eSewa Verification Phone</label>
                    <input
                      type="tel"
                      required
                      value={esewaNum}
                      onChange={(e) => setEsewaNum(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">eSewa QR Code Image URL</label>
                    <input
                      type="text"
                      required
                      value={esewaQr}
                      onChange={(e) => setEsewaQr(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-xs"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-xs font-black uppercase text-violet-400 border-b border-slate-850 pb-2">Khalti Parameters</h3>
                  
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Khalti Verification Phone</label>
                    <input
                      type="tel"
                      required
                      value={khaltiNum}
                      onChange={(e) => setKhaltiNum(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Khalti QR Code Image URL</label>
                    <input
                      type="text"
                      required
                      value={khaltiQr}
                      onChange={(e) => setKhaltiQr(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-xs"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-slate-850 pt-6">
                <div>
                  <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Min Deposit Limit (Rs.)</label>
                  <input
                    type="number"
                    required
                    value={minDep}
                    onChange={(e) => setMinDep(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Min Withdrawal Limit (Rs.)</label>
                  <input
                    type="number"
                    required
                    value={minWdr}
                    onChange={(e) => setMinWdr(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold py-3.5 px-4 rounded-xl text-sm"
              >
                Save Settings Configuration
              </button>

            </form>
          </div>
        )}

        {/* Announcements / FAQs content tab */}
        {activeTab === 'content' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                Content & <span className="text-red-500">Announcements</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Manage notification banners and list questions in landing page</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Broadcast Alert */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-4">
                <h3 className="text-base font-extrabold text-white uppercase tracking-wider">Create Board Announcement</h3>
                
                <form onSubmit={handleAddAnnouncement} className="space-y-4">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Alert Title</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Server Maintenance Scheduled"
                      value={annTitle}
                      onChange={(e) => setAnnTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Description Content</label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Enter announcement description..."
                      value={annContent}
                      onChange={(e) => setAnnContent(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-xs resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Banner Type Accent</label>
                    <select
                      value={annType}
                      onChange={(e) => setAnnType(e.target.value as 'info' | 'warning' | 'success')}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-xs"
                    >
                      <option value="info">Info (Cyan glow)</option>
                      <option value="warning">Warning (Amber glow)</option>
                      <option value="success">Success (Emerald glow)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-red-650 to-amber-600 text-white font-bold py-3 px-4 rounded-xl text-xs uppercase"
                  >
                    Broadcast Banner
                  </button>
                </form>

                {/* Announcement List */}
                <div className="border-t border-slate-850 pt-4 space-y-2">
                  <p className="text-xs text-slate-500 font-bold uppercase">Active Board Banners</p>
                  <div className="space-y-2 max-h-[200px] overflow-y-auto">
                    {announcements.map((a) => (
                      <div key={a.id} className="p-3 bg-slate-950 rounded-xl border border-slate-850 flex justify-between items-start gap-4">
                        <div>
                          <p className="text-xs font-bold text-white">{a.title}</p>
                          <p className="text-[10px] text-slate-400 mt-1">{a.content}</p>
                        </div>
                        <button
                          onClick={() => handleDeleteAnnouncement(a.id)}
                          className="text-rose-500 hover:text-rose-400 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* FAQS management */}
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-4">
                <h3 className="text-base font-extrabold text-white uppercase tracking-wider">FAQ Manager</h3>
                
                <form onSubmit={handleAddFaq} className="space-y-4">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Question Title</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. What games are supported?"
                      value={faqQuestion}
                      onChange={(e) => setFaqQuestion(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-500 font-bold uppercase mb-2">Detailed Answer</label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Enter detailed faq response..."
                      value={faqAnswer}
                      onChange={(e) => setFaqAnswer(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-xs resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-red-650 to-amber-600 text-white font-bold py-3 px-4 rounded-xl text-xs uppercase"
                  >
                    Add FAQ Item
                  </button>
                </form>

                {/* FAQ List */}
                <div className="border-t border-slate-850 pt-4 space-y-2">
                  <p className="text-xs text-slate-500 font-bold uppercase">Frequently Asked Questions ({faqs.length})</p>
                  <div className="space-y-2 max-h-[200px] overflow-y-auto">
                    {faqs.map((f) => (
                      <div key={f.id} className="p-3 bg-slate-950 rounded-xl border border-slate-850 flex justify-between items-start gap-4">
                        <div>
                          <p className="text-xs font-bold text-white">{f.question}</p>
                        </div>
                        <button
                          onClick={() => handleDeleteFaq(f.id)}
                          className="text-rose-500 hover:text-rose-400 p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}

        {/* Audit Logs tab */}
        {activeTab === 'logs' && (
          <div className="space-y-8 animate-in fade-in duration-200">
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wider">
                System <span className="text-red-500">Audit Logs</span>
              </h2>
              <p className="text-slate-400 text-xs mt-1">Real-time log trail of active sessions, deposits and results published</p>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-4">Security Logs</h3>
              <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
                {systemLogs.map((log) => (
                  <div key={log.id} className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex justify-between items-center text-xs">
                    <div>
                      <p className="text-slate-300 font-medium">
                        User <span className="text-white font-extrabold">{log.username}</span>: {log.action}
                      </p>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5">IP: {log.ip || 'Local Network'}</p>
                    </div>

                    <span className="text-[9px] text-slate-500">{new Date(log.createdAt).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </main>

      {/* Adjust User Balance Dialog Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-850 rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setEditingUser(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold font-mono"
            >
              &times;
            </button>

            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-2">Adjust User Balances</h3>
            <p className="text-xs text-slate-400 mb-6">Editing balance configurations for player <span className="font-extrabold text-white">{editingUser.username}</span>.</p>

            <form onSubmit={handleEditUserBalanceSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Wallet balance (Rs.)</label>
                <input
                  type="number"
                  required
                  value={editWalletBal}
                  onChange={(e) => setEditWalletBal(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Bonus Coins</label>
                <input
                  type="number"
                  required
                  value={editCoinsBal}
                  onChange={(e) => setEditCoinsBal(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white text-sm"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-red-650 to-amber-600 text-white font-bold py-3 px-4 rounded-xl text-sm"
                >
                  Save Balances
                </button>
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-5 py-3 bg-slate-950 border border-slate-800 text-slate-400 font-bold rounded-xl text-sm"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Tournament Build Modal */}
      {isTourModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-850 rounded-3xl max-w-xl w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setIsTourModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold"
            >
              &times;
            </button>

            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6">
              {tourFormMode === 'create' ? 'Create New Tournament' : 'Modify Tournament Details'}
            </h3>

            <form onSubmit={handleTournamentSubmit} className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Tournament Title</label>
                <input
                  type="text"
                  required
                  value={tourTitle}
                  onChange={(e) => setTourTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-4 text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Game Select</label>
                  <select
                    value={tourGame}
                    onChange={(e) => setTourGame(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  >
                    <option value="Free Fire">Free Fire</option>
                    <option value="PUBG Mobile">PUBG Mobile</option>
                    <option value="Mobile Legends">Mobile Legends</option>
                    <option value="eFootball">eFootball</option>
                    <option value="Other">Other Game</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Format</label>
                  <select
                    value={tourFormat}
                    onChange={(e) => setTourFormat(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  >
                    <option value="Solo">Solo</option>
                    <option value="Duo">Duo</option>
                    <option value="Squad">Squad</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Bracket Type</label>
                  <select
                    value={tourBracket}
                    onChange={(e) => setTourBracket(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  >
                    <option value="Single Elimination">Single Elimination</option>
                    <option value="Double Elimination">Double Elimination</option>
                    <option value="Round Robin">Round Robin</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Entry Fee (Rs.)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={tourEntryFee}
                    onChange={(e) => setTourEntryFee(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Prize Pool (Rs.)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={tourPrizePool}
                    onChange={(e) => setTourPrizePool(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Total Slots</label>
                  <input
                    type="number"
                    required
                    min={2}
                    value={tourSlots}
                    onChange={(e) => setTourSlots(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Match Start Time</label>
                  <input
                    type="datetime-local"
                    required
                    value={tourStartTime}
                    onChange={(e) => setTourStartTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Banner Image URL</label>
                  <input
                    type="text"
                    placeholder="Unsplash / Image URL"
                    value={tourBanner}
                    onChange={(e) => setTourBanner(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase mb-2">Match Rules (One per line)</label>
                <textarea
                  rows={4}
                  value={tourRules}
                  onChange={(e) => setTourRules(e.target.value)}
                  placeholder="Rule 1&#10;Rule 2&#10;Rule 3..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-3 text-white text-xs resize-none"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-red-655 to-amber-600 text-white font-bold py-3 px-4 rounded-xl text-xs uppercase"
                >
                  Save Tournament Configuration
                </button>
                <button
                  type="button"
                  onClick={() => setIsTourModalOpen(false)}
                  className="px-5 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-400 font-semibold text-xs"
                >
                  Cancel
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Declare Winners Modal */}
      {publishTour && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-850 rounded-3xl max-w-lg w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setPublishTour(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold font-mono"
            >
              &times;
            </button>

            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-2">Publish Match Standings</h3>
            <p className="text-xs text-slate-400 mb-6">Declaring winners for <span className="font-extrabold text-white">{publishTour.title}</span>. Match status will set to Completed.</p>

            <form onSubmit={handlePublishResults} className="space-y-6">
              
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-850">
                <p className="text-[10px] text-slate-500 font-bold uppercase mb-3">Lobby Registered Nicknames (Match one of these exactly)</p>
                <div className="flex flex-wrap gap-2 max-h-[100px] overflow-y-auto">
                  {publishTour.participants.map((p, idx) => (
                    <span key={idx} className="bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-[10px] text-cyan-400 font-mono select-all">
                      {p.username}
                    </span>
                  ))}
                  {publishTour.participants.length === 0 && (
                    <p className="text-xs text-rose-400 font-semibold">No participants registered. Winnings cannot be auto credited.</p>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Rank 1 Username</label>
                    <input
                      type="text"
                      required
                      placeholder="Exact username"
                      value={winner1Name}
                      onChange={(e) => setWinner1Name(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Rank 1 Prize (Rs.)</label>
                    <input
                      type="number"
                      required
                      value={winner1Prize}
                      onChange={(e) => setWinner1Prize(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Rank 2 Username</label>
                    <input
                      type="text"
                      placeholder="Exact username"
                      value={winner2Name}
                      onChange={(e) => setWinner2Name(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Rank 2 Prize (Rs.)</label>
                    <input
                      type="number"
                      value={winner2Prize}
                      onChange={(e) => setWinner2Prize(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Rank 3 Username</label>
                    <input
                      type="text"
                      placeholder="Exact username"
                      value={winner3Name}
                      onChange={(e) => setWinner3Name(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Rank 3 Prize (Rs.)</label>
                    <input
                      type="number"
                      value={winner3Prize}
                      onChange={(e) => setWinner3Prize(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-red-650 to-amber-600 text-white font-bold py-3 px-4 rounded-xl text-xs uppercase"
                >
                  Publish Standings & Pay Out
                </button>
                <button
                  type="button"
                  onClick={() => setPublishTour(null)}
                  className="px-5 py-3 bg-slate-950 border border-slate-800 text-slate-400 rounded-xl text-xs font-bold"
                >
                  Cancel
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
