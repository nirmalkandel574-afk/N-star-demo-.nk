import React, { useState, useEffect, useRef } from 'react';
import { User, SpinReward, SpinLog, getConfig, getSpins, saveSpins, getUsers, saveUsers, addLog } from '../utils/db';
import { Sparkles, Calendar, HelpCircle, Gift } from 'lucide-react';

interface SpinWheelProps {
  currentUser: User;
  onUpdateUser: (user: User) => void;
  notify: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const SpinWheel: React.FC<SpinWheelProps> = ({
  currentUser,
  onUpdateUser,
  notify,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  const [spinning, setSpinning] = useState(false);
  const [spinLogs, setSpinLogs] = useState<SpinLog[]>([]);
  const [rewards, setRewards] = useState<SpinReward[]>([]);
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [isSpinAvailable, setIsSpinAvailable] = useState<boolean>(true);

  // Load configuration and spin history
  useEffect(() => {
    const config = getConfig();
    setRewards(config.spinRewards || []);
    
    const logs = getSpins();
    const userLogs = logs.filter(log => log.userId === currentUser.id);
    setSpinLogs(userLogs);
    
    checkSpinCooldown();
  }, [currentUser]);

  // Check if spin is available
  const checkSpinCooldown = () => {
    if (!currentUser.lastSpinDate) {
      setIsSpinAvailable(true);
      return;
    }

    const lastSpin = new Date(currentUser.lastSpinDate).getTime();
    const nextSpin = lastSpin + 24 * 60 * 60 * 1000; // 24 hours cooldown
    const now = Date.now();

    if (now >= nextSpin) {
      setIsSpinAvailable(true);
      setTimeLeft('');
    } else {
      setIsSpinAvailable(false);
      
      // Calculate remaining time
      const diff = nextSpin - now;
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
    }
  };

  // Cooldown countdown interval
  useEffect(() => {
    const interval = setInterval(() => {
      checkSpinCooldown();
    }, 1000);
    return () => clearInterval(interval);
  }, [currentUser.lastSpinDate]);

  // Draw the spin wheel on the Canvas
  useEffect(() => {
    if (!canvasRef.current || rewards.length === 0) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(centerX, centerY) - 15;

    ctx.clearRect(0, 0, width, height);

    // Draw Wheel sectors
    const numSectors = rewards.length;
    const arcSize = (2 * Math.PI) / numSectors;

    const colors = [
      '#1e1b4b', '#312e81', '#4c1d95', '#581c87',
      '#0f172a', '#1e293b', '#030712', '#020617'
    ];

    rewards.forEach((reward, i) => {
      const angle = i * arcSize;
      
      ctx.beginPath();
      ctx.fillStyle = colors[i % colors.length];
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, angle, angle + arcSize);
      ctx.lineTo(centerX, centerY);
      ctx.fill();

      // Border lines
      ctx.strokeStyle = '#6366f1';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Text drawing
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(angle + arcSize / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      
      // Draw label
      ctx.fillText(reward.label, radius - 20, 4);
      ctx.restore();
    });

    // Draw Center Circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, 30, 0, 2 * Math.PI);
    ctx.fillStyle = '#6366f1';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Draw Center Arrow
    ctx.beginPath();
    ctx.moveTo(centerX - 10, centerY);
    ctx.lineTo(centerX + 10, centerY);
    ctx.lineTo(centerX, centerY - 45);
    ctx.closePath();
    ctx.fillStyle = '#06b6d4';
    ctx.fill();
  }, [rewards]);

  const spin = () => {
    if (spinning || !isSpinAvailable) return;
    
    setSpinning(true);
    
    // Choose winning item based on probability
    let winningIndex = 0;
    const rand = Math.random() * 100;
    let accum = 0;
    
    for (let i = 0; i < rewards.length; i++) {
      accum += rewards[i].probability;
      if (rand <= accum) {
        winningIndex = i;
        break;
      }
    }
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const numSectors = rewards.length;
    const sectorAngle = 360 / numSectors;
    
    // Rotate canvas simulation
    let currentRotation = 0;
    const targetSectorCenter = 360 - (winningIndex * sectorAngle + sectorAngle / 2);
    // Add multiple full rotations for effect
    const finalRotation = targetSectorCenter + 360 * 5; 
    const duration = 4000; // 4 seconds spin
    const startTime = performance.now();

    const animateSpin = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing out quadratic function
      const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
      currentRotation = finalRotation * easeOut(progress);

      if (canvas) {
        canvas.style.transform = `rotate(${currentRotation}deg)`;
      }

      if (progress < 1) {
        requestAnimationFrame(animateSpin);
      } else {
        handleSpinComplete(rewards[winningIndex]);
      }
    };

    requestAnimationFrame(animateSpin);
  };

  const handleSpinComplete = (reward: SpinReward) => {
    setSpinning(false);
    
    // Apply rewards based on type
    const users = getUsers();
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    if (userIndex === -1) return;

    const updatedUser = { ...users[userIndex] };
    
    if (reward.type === 'wallet') {
      updatedUser.walletBalance = Number((updatedUser.walletBalance + reward.value).toFixed(2));
      notify(`Congratulations! You won Rs. ${reward.value} Wallet Cash!`, 'success');
    } else if (reward.type === 'coins') {
      updatedUser.bonusCoins += reward.value;
      notify(`Congratulations! You won ${reward.value} Bonus Coins!`, 'success');
    } else if (reward.type === 'free_entry') {
      // Award free ticket in form of cash (Rs 10 equivalent)
      updatedUser.walletBalance = Number((updatedUser.walletBalance + 10).toFixed(2));
      notify(`Congratulations! You won a Free Ticket worth Rs. 10 (Credited to wallet)!`, 'success');
    } else if (reward.type === 'cashback') {
      updatedUser.walletBalance = Number((updatedUser.walletBalance + reward.value).toFixed(2));
      notify(`Congratulations! You won Rs. ${reward.value} Cashback!`, 'success');
    } else {
      notify('Try again tomorrow! Daily reward completed.', 'info');
    }

    // Set last spin date
    updatedUser.lastSpinDate = new Date().toISOString();
    users[userIndex] = updatedUser;
    saveUsers(users);
    
    // Log transaction if financial
    if (reward.type !== 'better_luck' && reward.value > 0) {
      const txs = JSON.parse(localStorage.getItem('nimz_transactions') || '[]');
      txs.unshift({
        id: 'tx_spin_' + Date.now(),
        userId: currentUser.id,
        username: currentUser.username,
        type: 'daily_spin',
        amount: reward.type === 'free_entry' ? 10 : reward.value,
        method: 'System',
        status: 'approved',
        createdAt: new Date().toISOString()
      });
      localStorage.setItem('nimz_transactions', JSON.stringify(txs));
    }

    // Save Spin Log
    const newSpinLog: SpinLog = {
      id: 'spinlog_' + Date.now(),
      userId: currentUser.id,
      username: currentUser.username,
      rewardLabel: reward.label,
      rewardType: reward.type,
      rewardValue: reward.value,
      createdAt: new Date().toISOString()
    };
    
    const allSpins = getSpins();
    allSpins.unshift(newSpinLog);
    saveSpins(allSpins);

    // Refresh UI
    onUpdateUser(updatedUser);
    addLog(currentUser.id, currentUser.username, `Spun daily wheel: won ${reward.label}`);
    
    // Refresh local lists
    setSpinLogs(allSpins.filter(log => log.userId === currentUser.id));
    checkSpinCooldown();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Overview Dashboard Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-white uppercase tracking-wider flex items-center gap-2">
            <Gift className="w-7 h-7 text-cyan-400" />
            Spin & <span className="bg-gradient-to-r from-cyan-400 to-violet-500 bg-clip-text text-transparent">Win</span>
          </h2>
          <p className="text-slate-400 text-xs mt-1">Spin the daily wheel of fortune to earn cash prizes and bonus coins</p>
        </div>

        <div className="flex gap-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-950/50 border border-cyan-800 flex items-center justify-center text-cyan-400 font-extrabold text-sm">
              Rs
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-semibold">Wallet Cash</p>
              <p className="text-sm font-extrabold text-white">Rs. {currentUser.walletBalance}</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-violet-950/50 border border-violet-800 flex items-center justify-center text-violet-400 font-extrabold text-sm">
              🪙
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-semibold">Bonus Coins</p>
              <p className="text-sm font-extrabold text-white">{currentUser.bonusCoins} Coins</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Wheel Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* The Wheel */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 flex flex-col items-center justify-center relative overflow-hidden">
          
          {/* Decorative backdrop glow */}
          <div className="absolute w-72 h-72 bg-violet-600/5 rounded-full blur-[80px] pointer-events-none" />

          {/* Canvas Wrapper */}
          <div className="relative w-72 h-72 md:w-80 md:h-80 my-6">
            
            {/* Pointer pin at the top */}
            <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 z-20 w-5 h-8 flex items-center justify-center">
              <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[20px] border-t-cyan-400 drop-shadow-[0_4px_6px_rgba(6,182,212,0.4)]" />
            </div>

            {/* Canvas */}
            <canvas
              ref={canvasRef}
              width={350}
              height={350}
              style={{ transition: 'transform 4s ease-out' }}
              className="w-full h-full rounded-full border-4 border-slate-950 shadow-[0_0_40px_rgba(99,102,241,0.25)] bg-slate-950"
            />
          </div>

          {/* Controls */}
          <div className="text-center mt-4 relative z-10">
            {isSpinAvailable ? (
              <button
                onClick={spin}
                disabled={spinning}
                className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 disabled:opacity-50 text-white font-extrabold rounded-xl shadow-[0_0_25px_rgba(139,92,246,0.4)] hover:shadow-[0_0_35px_rgba(139,92,246,0.6)] transition-all cursor-pointer transform active:scale-95"
              >
                {spinning ? 'SPINNING...' : 'SPIN WHEEL'}
              </button>
            ) : (
              <div className="space-y-2">
                <button
                  disabled
                  className="px-8 py-3 bg-slate-800 text-slate-500 font-extrabold rounded-xl border border-slate-700 cursor-not-allowed"
                >
                  SPIN LOCKED
                </button>
                <p className="text-xs text-rose-400 font-bold flex items-center gap-1.5 justify-center">
                  <Calendar className="w-3.5 h-3.5" />
                  Next spin available in: {timeLeft || 'Calculating...'}
                </p>
              </div>
            )}
            <p className="text-[10px] text-slate-500 mt-3">Allows 1 spin per day. Spin rewards are processed instantly.</p>
          </div>
        </div>

        {/* Spin Logs and Rules */}
        <div className="space-y-6">
          
          {/* Rules */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
            <h3 className="font-extrabold text-white text-sm uppercase tracking-wider mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              Spin Rules
            </h3>
            <ul className="text-xs text-slate-400 space-y-2 list-disc list-inside">
              <li>Every player gets one free spin every 24 hours.</li>
              <li>Winnings are automatically deposited to your wallet or coin count.</li>
              <li>Admin configurations define the probabilities of each sector.</li>
              <li>Using multiple accounts to spin will result in a permanent ban.</li>
            </ul>
          </div>

          {/* Logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex-grow">
            <h3 className="font-extrabold text-white text-sm uppercase tracking-wider mb-4">
              Your Spin History
            </h3>
            
            <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
              {spinLogs.length > 0 ? (
                spinLogs.map((log) => (
                  <div key={log.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
                    <div>
                      <p className="text-xs font-bold text-slate-300">{log.rewardLabel}</p>
                      <p className="text-[10px] text-slate-500">{new Date(log.createdAt).toLocaleString()}</p>
                    </div>
                    <span className="text-[10px] uppercase font-extrabold bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-800/40">
                      Success
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <HelpCircle className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p className="text-xs text-slate-500">You haven't spun the wheel yet.</p>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
