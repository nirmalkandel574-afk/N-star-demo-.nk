import React, { useState } from 'react';
import { Tournament, User, getUsers, getTournaments, getFAQs } from '../utils/db';
import { 
  Trophy, Flame, ShieldCheck, Mail, MessageSquare, 
  ChevronDown, ChevronUp, ArrowRight, Play, Award 
} from 'lucide-react';

interface LandingPageProps {
  onJoinClick: (tournament: Tournament) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  currentUser: User | null;
  onNavigateToDashboard: (tab?: string) => void;
  notify: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onJoinClick,
  onOpenAuth,
  currentUser,
  onNavigateToDashboard,
  notify,
}) => {
  const tournaments = getTournaments();
  const users = getUsers();
  const faqs = getFAQs();

  // Contact Form State
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  
  // Modals for Terms & Privacy
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);

  // Active Leaderboard Category
  const [leaderboardTab, setLeaderboardTab] = useState<'earners' | 'referrals' | 'played'>('earners');

  // FAQ Expanded State
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>(null);

  // Filter Tournaments
  const [activeGameFilter, setActiveGameFilter] = useState<string>('All');
  
  const gamesList = ['All', 'Free Fire', 'PUBG Mobile', 'Mobile Legends', 'eFootball', 'Other'];

  const filteredTournaments = activeGameFilter === 'All'
    ? tournaments
    : tournaments.filter(t => t.game === activeGameFilter);

  // Get Top Earners
  const topEarners = [...users]
    .sort((a, b) => b.walletBalance - a.walletBalance)
    .slice(0, 5);

  // Get Top Referrals
  const topReferrers = [...users]
    .sort((a, b) => b.referralsCount - a.referralsCount)
    .slice(0, 5);

  // Get Mock Top Played (based on length of registered games or mock stats)
  const topPlayed = [...users]
    .sort((a, b) => (Object.keys(a.gameNicknames).length || 0) - (Object.keys(b.gameNicknames).length || 0))
    .slice(0, 5);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMessage) {
      notify('Please fill out all fields in the contact form.', 'error');
      return;
    }
    
    // Save contact message to local storage
    const messages = JSON.parse(localStorage.getItem('nimz_contact_messages') || '[]');
    messages.push({
      id: 'msg_' + Date.now(),
      name: contactName,
      email: contactEmail,
      message: contactMessage,
      createdAt: new Date().toISOString()
    });
    localStorage.setItem('nimz_contact_messages', JSON.stringify(messages));
    
    notify('Thank you for contacting Nimz Battle. We will get back to you shortly!', 'success');
    setContactName('');
    setContactEmail('');
    setContactMessage('');
  };

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen font-sans selection:bg-cyan-500 selection:text-black">
      
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden pt-32 pb-20 md:pt-40 md:pb-32 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-violet-900/40 via-slate-950 to-slate-950">
        
        {/* Background Decorative Grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
        
        {/* Floating Neon Orbs */}
        <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-violet-950/80 border border-violet-800 text-violet-400 text-xs font-bold uppercase tracking-wider mb-6 animate-pulse">
            <Flame className="w-4 h-4 text-cyan-400" />
            Empowering Nepalese Gamers
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white mb-6 uppercase leading-none">
            Unleash Your Skill<br/>
            <span className="bg-gradient-to-r from-cyan-400 via-violet-400 to-fuchsia-500 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">
              Earn Real Rewards
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-slate-400 text-base sm:text-xl mb-10 font-medium">
            Join daily Free Fire, PUBG, Mobile Legends, and eFootball tournaments. Compete with top players across Nepal and withdraw your earnings instantly via eSewa & Khalti.
          </p>

          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            {currentUser ? (
              <button
                onClick={() => onNavigateToDashboard('tournaments')}
                className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold rounded-xl shadow-[0_0_30px_rgba(139,92,246,0.5)] transition-all cursor-pointer transform hover:-translate-y-1 flex items-center justify-center gap-2 group"
              >
                Go to Dashboard
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            ) : (
              <>
                <button
                  onClick={() => onOpenAuth('register')}
                  className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold rounded-xl shadow-[0_0_30px_rgba(139,92,246,0.5)] transition-all cursor-pointer transform hover:-translate-y-1 flex items-center justify-center gap-2 group"
                >
                  Start Earning Now
                  <Play className="w-4 h-4 fill-white" />
                </button>
                <button
                  onClick={() => onOpenAuth('login')}
                  className="w-full sm:w-auto px-8 py-4 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl border border-slate-700 hover:border-cyan-500 transition-all cursor-pointer"
                >
                  Watch Demo
                </button>
              </>
            )}
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto mt-20 p-6 rounded-2xl bg-slate-900/50 backdrop-blur-md border border-slate-800/80">
            <div className="text-center p-2 border-r border-slate-800 last:border-0">
              <p className="text-3xl sm:text-4xl font-extrabold text-cyan-400">120+</p>
              <p className="text-xs sm:text-sm text-slate-400 font-medium mt-1">Daily Tournaments</p>
            </div>
            <div className="text-center p-2 border-r border-slate-800 last:border-0">
              <p className="text-3xl sm:text-4xl font-extrabold text-violet-400">Rs. 1.5M+</p>
              <p className="text-xs sm:text-sm text-slate-400 font-medium mt-1">Prize Paid Out</p>
            </div>
            <div className="text-center p-2 border-r border-slate-800 last:border-0">
              <p className="text-3xl sm:text-4xl font-extrabold text-fuchsia-400">4,500+</p>
              <p className="text-xs sm:text-sm text-slate-400 font-medium mt-1">Active Players</p>
            </div>
            <div className="text-center p-2 last:border-0">
              <p className="text-3xl sm:text-4xl font-extrabold text-emerald-400">Instant</p>
              <p className="text-xs sm:text-sm text-slate-400 font-medium mt-1">eSewa/Khalti Cashouts</p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Featured Tournaments */}
      <section id="tournaments" className="py-20 bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
            <div>
              <h2 className="text-3xl font-extrabold text-white uppercase tracking-wider flex items-center gap-3">
                <Trophy className="w-8 h-8 text-cyan-400" />
                Featured <span className="bg-gradient-to-r from-cyan-400 to-violet-500 bg-clip-text text-transparent">Tournaments</span>
              </h2>
              <p className="text-slate-400 mt-2">Join live matches, secure your slots and battle for the victory cash pool.</p>
            </div>

            {/* Game Category Filters */}
            <div className="flex flex-wrap gap-2 mt-6 md:mt-0 bg-slate-900/60 p-1.5 rounded-xl border border-slate-800 overflow-x-auto max-w-full">
              {gamesList.map((game) => (
                <button
                  key={game}
                  onClick={() => setActiveGameFilter(game)}
                  className={`px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all whitespace-nowrap ${
                    activeGameFilter === game
                      ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {game}
                </button>
              ))}
            </div>
          </div>

          {/* Tournament Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredTournaments.length > 0 ? (
              filteredTournaments.map((tour) => {
                const isJoined = currentUser && tour.registeredPlayers.includes(currentUser.id);
                return (
                  <div
                    key={tour.id}
                    className="group bg-slate-900 border border-slate-800 hover:border-violet-700 rounded-2xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-[0_0_30px_rgba(139,92,246,0.15)] flex flex-col h-full"
                  >
                    {/* Banner Image */}
                    <div className="relative h-48 overflow-hidden bg-slate-950">
                      <img
                        src={tour.bannerUrl}
                        alt={tour.title}
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute top-4 right-4 bg-cyan-500 text-black font-extrabold text-xs px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                        {tour.game}
                      </div>
                      <div className="absolute bottom-4 left-4 bg-slate-950/80 backdrop-blur-sm border border-slate-800 text-white text-xs px-2.5 py-1 rounded-md font-semibold">
                        Format: {tour.format} | {tour.bracketType}
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-6 flex flex-col flex-grow">
                      <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors mb-4 line-clamp-1">
                        {tour.title}
                      </h3>

                      <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                        <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/80">
                          <p className="text-xs text-slate-500 uppercase font-semibold">Prize Pool</p>
                          <p className="text-base font-extrabold text-emerald-400">Rs. {tour.prizePool}</p>
                        </div>
                        <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/80">
                          <p className="text-xs text-slate-500 uppercase font-semibold">Entry Fee</p>
                          <p className={`text-base font-extrabold ${tour.entryFee === 0 ? 'text-cyan-400' : 'text-slate-200'}`}>
                            {tour.entryFee === 0 ? 'FREE' : `Rs. ${tour.entryFee}`}
                          </p>
                        </div>
                      </div>

                      {/* Progress Bar & Slots */}
                      <div className="mb-6">
                        <div className="flex justify-between text-xs font-semibold mb-2">
                          <span className="text-slate-400">Slots Booked</span>
                          <span className="text-cyan-400">{tour.registeredPlayers.length} / {tour.totalSlots}</span>
                        </div>
                        <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                          <div
                            className="bg-gradient-to-r from-cyan-500 to-violet-600 h-full rounded-full transition-all duration-500"
                            style={{ width: `${(tour.registeredPlayers.length / tour.totalSlots) * 100}%` }}
                          />
                        </div>
                      </div>

                      {/* Action Button */}
                      <div className="mt-auto">
                        <button
                          onClick={() => onJoinClick(tour)}
                          className={`w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                            tour.status === 'completed'
                              ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
                              : isJoined
                              ? 'bg-violet-900/30 text-violet-400 border border-violet-800 hover:bg-violet-900/40'
                              : 'bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white shadow-md'
                          }`}
                        >
                          {tour.status === 'completed' ? (
                            <>
                              <Award className="w-5 h-5 text-yellow-500" />
                              View Results
                            </>
                          ) : isJoined ? (
                            'Already Joined (View Details)'
                          ) : (
                            'Join Tournament'
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="col-span-full text-center py-16 bg-slate-900/30 rounded-2xl border border-slate-800">
                <p className="text-slate-400 font-semibold">No tournaments found for this category.</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 3. Leaderboard & Stats */}
      <section id="leaderboard" className="py-20 bg-slate-900/30 border-y border-slate-900 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
            
            {/* Top Leaderboard Card */}
            <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-wider">
                    Hall of <span className="text-cyan-400">Champions</span>
                  </h3>
                  <p className="text-slate-400 text-xs mt-1">Platform top performers updated real-time</p>
                </div>

                {/* Tabs */}
                <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                  <button
                    onClick={() => setLeaderboardTab('earners')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      leaderboardTab === 'earners' ? 'bg-cyan-500 text-black' : 'text-slate-400'
                    }`}
                  >
                    Top Earners
                  </button>
                  <button
                    onClick={() => setLeaderboardTab('referrals')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      leaderboardTab === 'referrals' ? 'bg-cyan-500 text-black' : 'text-slate-400'
                    }`}
                  >
                    Referrals
                  </button>
                  <button
                    onClick={() => setLeaderboardTab('played')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                      leaderboardTab === 'played' ? 'bg-cyan-500 text-black' : 'text-slate-400'
                    }`}
                  >
                    Active Users
                  </button>
                </div>
              </div>

              {/* Leaderboard Entries */}
              <div className="space-y-3">
                {leaderboardTab === 'earners' && topEarners.map((user, idx) => (
                  <div key={user.id} className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 transition-all">
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                        idx === 0 ? 'bg-yellow-500 text-black' : idx === 1 ? 'bg-slate-400 text-black' : idx === 2 ? 'bg-amber-600 text-white' : 'bg-slate-900 text-slate-400'
                      }`}>
                        #{idx + 1}
                      </span>
                      <img src={user.avatarUrl} alt={user.username} className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700" />
                      <div>
                        <p className="font-bold text-white text-sm flex items-center gap-1.5">
                          {user.username}
                          {user.role === 'admin' && <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.5 rounded font-black uppercase">Staff</span>}
                        </p>
                        <p className="text-[11px] text-slate-500">Joined {new Date(user.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-extrabold text-emerald-400 text-sm">Rs. {user.walletBalance}</p>
                      <p className="text-[10px] text-slate-400">{user.bonusCoins} Coins</p>
                    </div>
                  </div>
                ))}

                {leaderboardTab === 'referrals' && topReferrers.map((user, idx) => (
                  <div key={user.id} className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 transition-all">
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                        idx === 0 ? 'bg-yellow-500 text-black' : idx === 1 ? 'bg-slate-400 text-black' : idx === 2 ? 'bg-amber-600 text-white' : 'bg-slate-900 text-slate-400'
                      }`}>
                        #{idx + 1}
                      </span>
                      <img src={user.avatarUrl} alt={user.username} className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700" />
                      <div>
                        <p className="font-bold text-white text-sm">{user.username}</p>
                        <p className="text-[11px] text-slate-500">Code: {user.referralCode}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-extrabold text-cyan-400 text-sm">{user.referralsCount} Referrals</p>
                      <p className="text-[10px] text-slate-400">Earned Rs. {user.referralEarnings}</p>
                    </div>
                  </div>
                ))}

                {leaderboardTab === 'played' && topPlayed.map((user, idx) => (
                  <div key={user.id} className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 transition-all">
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                        idx === 0 ? 'bg-yellow-500 text-black' : idx === 1 ? 'bg-slate-400 text-black' : idx === 2 ? 'bg-amber-600 text-white' : 'bg-slate-900 text-slate-400'
                      }`}>
                        #{idx + 1}
                      </span>
                      <img src={user.avatarUrl} alt={user.username} className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700" />
                      <div>
                        <p className="font-bold text-white text-sm">{user.username}</p>
                        <p className="text-[11px] text-slate-500">{user.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-extrabold text-violet-400 text-sm">{Object.keys(user.gameNicknames).length || 1} Games Registered</p>
                      <p className="text-[10px] text-slate-400">{user.badges.join(', ') || 'Challenger'}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Latest Winners Feed & Achievements */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl flex flex-col justify-between h-full">
              <div>
                <h3 className="text-2xl font-black text-white uppercase tracking-wider mb-6 flex items-center gap-2">
                  <Award className="w-7 h-7 text-yellow-500" />
                  Live Winners
                </h3>
                
                {/* Scrolling Winner Cards */}
                <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
                  {tournaments.filter(t => t.status === 'completed').slice(0, 4).map((t) => (
                    <div key={t.id} className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
                      <p className="text-xs text-slate-500 uppercase font-bold">{t.game} - {t.title}</p>
                      <div className="mt-2 space-y-1">
                        {t.winners?.map((w, idx) => (
                          <div key={idx} className="flex justify-between items-center text-sm font-semibold">
                            <span className="text-slate-300 flex items-center gap-1.5">
                              <span className="text-yellow-500">🏆</span> {w.username}
                            </span>
                            <span className="text-emerald-400">Rs. {w.prize}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  {tournaments.filter(t => t.status === 'completed').length === 0 && (
                    <p className="text-slate-500 text-center py-8 text-sm">No match winners declared yet.</p>
                  )}
                </div>
              </div>

              {/* Instant Join referral banner */}
              <div className="mt-8 bg-gradient-to-tr from-cyan-950/60 to-violet-950/60 border border-violet-800/60 rounded-2xl p-5 relative overflow-hidden">
                <div className="absolute -top-10 -right-10 w-24 h-24 bg-cyan-500/10 rounded-full blur-xl pointer-events-none" />
                <h4 className="font-extrabold text-white text-base">Refer & Earn Rs. 2.50</h4>
                <p className="text-xs text-slate-400 mt-2">Get paid for every friend you refer. Cash is directly credited to your wallet balance instantly.</p>
                <button
                  onClick={() => onNavigateToDashboard('referrals')}
                  className="mt-4 flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-bold transition-all cursor-pointer"
                >
                  Generate Referral Link <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 4. FAQ Section */}
      <section id="faq" className="py-20 bg-slate-950">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-black text-white uppercase tracking-wider">
              Frequently Asked <span className="text-cyan-400">Questions</span>
            </h2>
            <p className="text-slate-400 mt-2">Find quick answers to common queries about deposits, brackets and tournaments.</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq) => {
              const isExpanded = expandedFaqId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden transition-all duration-300"
                >
                  <button
                    onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                    className="w-full text-left p-5 flex justify-between items-center text-white font-bold hover:bg-slate-800/50 transition-colors"
                  >
                    <span>{faq.question}</span>
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                    )}
                  </button>
                  {isExpanded && (
                    <div className="px-5 pb-5 pt-1 text-slate-400 text-sm leading-relaxed border-t border-slate-900">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 5. Contact Us */}
      <section id="contact" className="py-20 bg-slate-900/20 border-t border-slate-900">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            
            {/* Info */}
            <div>
              <h2 className="text-3xl font-black text-white uppercase tracking-wider">
                Get In <span className="text-cyan-400">Touch</span>
              </h2>
              <p className="text-slate-400 mt-4 leading-relaxed">
                Have custom queries, corporate tournaments sponsorship plans or technical difficulties? Write to us and our 24/7 dedicated Nepalese support desk will respond instantly.
              </p>

              <div className="mt-8 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-850 flex items-center justify-center text-cyan-400">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-semibold">Email Support</p>
                    <p className="text-sm font-bold text-white">support@nimzbattle.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-850 flex items-center justify-center text-cyan-400">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-semibold">Live Support Chat</p>
                    <p className="text-sm font-bold text-white">Available in Dashboard</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-850 flex items-center justify-center text-cyan-400">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-semibold">Compliance Desk</p>
                    <p className="text-sm font-bold text-white">Verified Local Payments</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-xl">
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your name"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Message</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Write your query here..."
                    value={contactMessage}
                    onChange={(e) => setContactMessage(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 px-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors text-sm resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold py-3 px-4 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all cursor-pointer text-center text-sm"
                >
                  Send Message
                </button>
              </form>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center md:text-left">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            
            {/* Logo */}
            <div>
              <h2 className="text-xl font-black tracking-wider text-white">
                NIMZ <span className="bg-gradient-to-r from-cyan-400 to-violet-400 bg-clip-text text-transparent">BATTLE</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">© {new Date().getFullYear()} Nimz Battle Inc. All Rights Reserved.</p>
            </div>

            {/* Links */}
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <button
                onClick={() => setShowTerms(true)}
                className="text-slate-400 hover:text-cyan-400 font-medium transition-colors cursor-pointer"
              >
                Terms & Conditions
              </button>
              <button
                onClick={() => setShowPrivacy(true)}
                className="text-slate-400 hover:text-cyan-400 font-medium transition-colors cursor-pointer"
              >
                Privacy Policy
              </button>
              <a
                href="#faq"
                className="text-slate-400 hover:text-cyan-400 font-medium transition-colors"
              >
                FAQs
              </a>
              <a
                href="#contact"
                className="text-slate-400 hover:text-cyan-400 font-medium transition-colors"
              >
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* TERMS MODAL */}
      {showTerms && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setShowTerms(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold"
            >
              &times;
            </button>
            <h3 className="text-xl font-extrabold text-white mb-4 uppercase">Terms and Conditions</h3>
            <div className="max-h-[60vh] overflow-y-auto text-xs text-slate-400 space-y-4 pr-1">
              <p className="font-bold text-slate-300">1. Acceptance of Terms</p>
              <p>By registering on Nimz Battle, you agree to comply with all guidelines, platform rules, and match laws. Tournament formats are decided by admin panel and matches must be conducted in fair gaming conditions.</p>
              <p className="font-bold text-slate-300">2. Financial Transactions</p>
              <p>Minimum deposit is Rs. 10 and minimum withdrawal is Rs. 50. All payments are verified using physical transaction IDs and payment screenshots. Processing takes 5-15 minutes but can take up to 24 hours in some scenarios.</p>
              <p className="font-bold text-slate-300">3. Cheating & Abuse Policies</p>
              <p>Any use of software modifications, emulators in mobile tournaments, or verbal abuse in game rooms will result in immediate ban, loss of wallet balance, and disqualification.</p>
            </div>
            <button
              onClick={() => setShowTerms(false)}
              className="w-full mt-6 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2.5 rounded-xl text-sm"
            >
              Close Guidelines
            </button>
          </div>
        </div>
      )}

      {/* PRIVACY MODAL */}
      {showPrivacy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 md:p-8 shadow-2xl relative">
            <button
              onClick={() => setShowPrivacy(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl font-bold"
            >
              &times;
            </button>
            <h3 className="text-xl font-extrabold text-white mb-4 uppercase">Privacy Policy</h3>
            <div className="max-h-[60vh] overflow-y-auto text-xs text-slate-400 space-y-4 pr-1">
              <p className="font-bold text-slate-300">1. Data Storage</p>
              <p>We respect your privacy. User emails, phone numbers, and in-game names are only collected for match setup and transaction verification purposes. We do not sell or share data with advertising agencies.</p>
              <p className="font-bold text-slate-300">2. Verification Credentials</p>
              <p>Payment screenshots and transaction IDs are stored locally for security audit logs. This prevents duplicate transaction submissions and ensures compliance with cyber safety laws.</p>
            </div>
            <button
              onClick={() => setShowPrivacy(false)}
              className="w-full mt-6 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2.5 rounded-xl text-sm"
            >
              Close Policy
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
