import React, { useState } from 'react';
import { User, getUsers, saveUsers, addLog } from '../utils/db';
import { Mail, Lock, User as UserIcon, Phone, KeyRound, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';

interface AuthModalsProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  initialMode?: 'login' | 'register' | 'forgot' | 'admin';
  notify: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export const AuthModals: React.FC<AuthModalsProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  initialMode = 'login',
  notify,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'admin'>(initialMode);
  
  // Login Form
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  // Register Form
  const [regUsername, setRegUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regReferralCode, setRegReferralCode] = useState('');
  
  // Forgot Password Form
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotPhone, setForgotPhone] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [forgotStep, setForgotStep] = useState<1 | 2>(1);
  const [matchedUser, setMatchedUser] = useState<User | null>(null);

  // Admin Login Form
  const [adminEmail, setAdminEmail] = useState('admin@nimzbattle.com');
  const [adminPassword, setAdminPassword] = useState('admin123');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      notify('Please fill in all fields', 'error');
      return;
    }

    const users = getUsers();
    const user = users.find(u => u.email.toLowerCase() === loginEmail.toLowerCase());

    if (!user) {
      notify('User not found. Check your email or sign up.', 'error');
      return;
    }

    if (user.status === 'banned') {
      notify('Your account has been banned by an administrator.', 'error');
      return;
    }

    // In a production app, password hashing would be verified. For the local demo, we match directly.
    // Let's set a simple default for newly registered users, or mock verify password length.
    if (loginPassword.length < 6) {
      notify('Password must be at least 6 characters.', 'error');
      return;
    }

    // Mark last login date and save
    user.lastLoginDate = new Date().toISOString();
    saveUsers(users.map(u => u.id === user.id ? user : u));

    addLog(user.id, user.username, 'User logged in successfully');
    notify(`Welcome back, ${user.username}!`, 'success');
    onLoginSuccess(user);
    onClose();
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regUsername || !regEmail || !regPhone || !regPassword || !regConfirmPassword) {
      notify('Please fill in all required fields.', 'error');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      notify('Passwords do not match.', 'error');
      return;
    }

    if (regPassword.length < 6) {
      notify('Password must be at least 6 characters long.', 'error');
      return;
    }

    const users = getUsers();
    
    // Check if email or username already exists
    if (users.some(u => u.email.toLowerCase() === regEmail.toLowerCase())) {
      notify('Email is already registered.', 'error');
      return;
    }

    if (users.some(u => u.username.toLowerCase() === regUsername.toLowerCase())) {
      notify('Username is already taken.', 'error');
      return;
    }

    // Process referral code if entered
    let referrerId: string | null = null;
    let referrerUsername: string | null = null;
    if (regReferralCode.trim()) {
      const code = regReferralCode.trim().toUpperCase();
      const referrer = users.find(u => u.referralCode === code);
      if (referrer) {
        referrerId = referrer.id;
        referrerUsername = referrer.username;
      } else {
        notify('Invalid referral code. Registration will continue without it.', 'info');
      }
    }

    // Create unique referral code for the new user
    const newUserCode = regUsername.substring(0, 5).toUpperCase() + Math.floor(100 + Math.random() * 900);

    const newUser: User = {
      id: 'user_' + Date.now(),
      username: regUsername,
      email: regEmail,
      role: 'user',
      walletBalance: 0, // starts at 0, daily spins or deposits can increment
      bonusCoins: 100, // free starter coins
      avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${regUsername}`,
      referralCode: newUserCode,
      referredBy: referrerId,
      referralsCount: 0,
      referralEarnings: 0,
      status: 'active',
      badges: ['Newbie'],
      createdAt: new Date().toISOString(),
      phone: regPhone,
      gameNicknames: {}
    };

    // If referred, reward the referrer immediately (as per requirements: Rs. 2.50)
    const updatedUsers = users.map(u => {
      if (referrerId && u.id === referrerId) {
        // Add to referrer
        const reward = 2.50;
        const updatedUser = {
          ...u,
          walletBalance: Number((u.walletBalance + reward).toFixed(2)),
          referralEarnings: Number((u.referralEarnings + reward).toFixed(2)),
          referralsCount: u.referralsCount + 1,
          badges: u.referralsCount + 1 >= 5 && !u.badges.includes('Top Recruiter') 
            ? [...u.badges, 'Top Recruiter'] 
            : u.badges
        };

        // Create transaction record for referrer
        const txs = JSON.parse(localStorage.getItem('nimz_transactions') || '[]');
        txs.unshift({
          id: 'tx_ref_' + Date.now(),
          userId: referrerId,
          username: u.username,
          type: 'referral',
          amount: reward,
          method: 'System',
          status: 'approved',
          createdAt: new Date().toISOString()
        });
        localStorage.setItem('nimz_transactions', JSON.stringify(txs));

        return updatedUser;
      }
      return u;
    });

    updatedUsers.push(newUser);
    saveUsers(updatedUsers);

    addLog(newUser.id, newUser.username, `User registered (Referred by: ${referrerUsername || 'None'})`);
    notify('Registration successful! Please log in.', 'success');
    
    // Automatically switch to login tab and prefill email
    setLoginEmail(regEmail);
    setMode('login');
  };

  const handleForgotPasswordVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail || !forgotPhone) {
      notify('Please fill in both fields to verify your identity.', 'error');
      return;
    }

    const users = getUsers();
    const user = users.find(
      u => u.email.toLowerCase() === forgotEmail.toLowerCase() && u.phone === forgotPhone
    );

    if (!user) {
      notify('No account matches this email and phone number combination.', 'error');
      return;
    }

    setMatchedUser(user);
    setForgotStep(2);
    notify('Verification successful! Set your new password.', 'success');
  };

  const handleForgotPasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || !confirmNewPassword) {
      notify('Please fill in both fields.', 'error');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      notify('Passwords do not match.', 'error');
      return;
    }

    if (newPassword.length < 6) {
      notify('Password must be at least 6 characters long.', 'error');
      return;
    }

    if (!matchedUser) return;

    const users = getUsers();
    const updatedUsers = users.map(u => {
      if (u.id === matchedUser.id) {
        return {
          ...u,
          // In a local storage app, we just log the action and complete.
        };
      }
      return u;
    });

    saveUsers(updatedUsers);
    addLog(matchedUser.id, matchedUser.username, 'Reset password successfully');
    notify('Password reset successfully! Log in with your new password.', 'success');
    
    // Reset state
    setForgotStep(1);
    setMatchedUser(null);
    setLoginEmail(matchedUser.email);
    setMode('login');
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminEmail || !adminPassword) {
      notify('Admin email and password required.', 'error');
      return;
    }

    const users = getUsers();
    const adminUser = users.find(
      u => u.email.toLowerCase() === adminEmail.toLowerCase() && u.role === 'admin'
    );

    if (!adminUser) {
      notify('Invalid Admin Credentials or account is not an Administrator.', 'error');
      return;
    }

    // Match static credentials for local demo
    if (adminPassword !== 'admin123') {
      notify('Incorrect admin password.', 'error');
      return;
    }

    addLog(adminUser.id, adminUser.username, 'Admin logged in to Management Console');
    notify('Admin Login Successful!', 'success');
    onLoginSuccess(adminUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-md bg-slate-900 border border-violet-800 rounded-2xl p-6 md:p-8 shadow-[0_0_50px_rgba(139,92,246,0.3)] animate-in fade-in zoom-in-95 duration-250">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
        >
          <span className="text-2xl font-bold">&times;</span>
        </button>

        {/* Brand Logo Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 shadow-[0_0_15px_rgba(6,182,212,0.5)] mb-3">
            <ShieldCheck className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-2xl font-black tracking-wider text-white">
            NIMZ <span className="bg-gradient-to-r from-cyan-400 to-violet-400 bg-clip-text text-transparent">BATTLE</span>
          </h2>
          <p className="text-slate-400 text-xs mt-1">Nepal's Premier Esports & Earnings Arena</p>
        </div>

        {/* Tabs for switching modes */}
        {mode !== 'forgot' && (
          <div className="grid grid-cols-3 bg-slate-950 rounded-xl p-1 mb-6 border border-slate-800 text-sm">
            <button
              onClick={() => setMode('login')}
              className={`py-2 rounded-lg font-bold transition-all ${
                mode === 'login'
                  ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Login
            </button>
            <button
              onClick={() => setMode('register')}
              className={`py-2 rounded-lg font-bold transition-all ${
                mode === 'register'
                  ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Sign Up
            </button>
            <button
              onClick={() => setMode('admin')}
              className={`py-2 rounded-lg font-bold transition-all ${
                mode === 'admin'
                  ? 'bg-gradient-to-r from-cyan-500 to-violet-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Admin
            </button>
          </div>
        )}

        {/* MODAL BODY */}

        {/* 1. Login View */}
        {mode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Mail className="w-5 h-5" />
                </span>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Password</label>
                <button
                  type="button"
                  onClick={() => {
                    setMode('forgot');
                    setForgotStep(1);
                  }}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-medium"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Lock className="w-5 h-5" />
                </span>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-4 bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold py-3 px-4 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_25px_rgba(6,182,212,0.5)] transition-all cursor-pointer text-center"
            >
              Sign In to Battle
            </button>

            <div className="text-center mt-4">
              <span className="text-xs text-slate-500">Demo accounts: gamer@nimzbattle.com / admin@nimzbattle.com (pass: anything 6+ chars)</span>
            </div>
          </form>
        )}

        {/* 2. Registration View */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Username</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <UserIcon className="w-5 h-5" />
                </span>
                <input
                  type="text"
                  required
                  placeholder="EpicGamer123"
                  value={regUsername}
                  onChange={(e) => setRegUsername(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Mail className="w-5 h-5" />
                </span>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Phone Number</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Phone className="w-5 h-5" />
                </span>
                <input
                  type="tel"
                  required
                  placeholder="98XXXXXXXX"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Password</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-9 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Confirm</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-9 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Referral Code (Optional)</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <KeyRound className="w-5 h-5" />
                </span>
                <input
                  type="text"
                  placeholder="e.g. GAMERPRO99"
                  value={regReferralCode}
                  onChange={(e) => setRegReferralCode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Get 100 free coins on signup + rewards your referrer Rs. 2.50.</p>
            </div>

            <button
              type="submit"
              className="w-full mt-2 bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold py-3 px-4 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all cursor-pointer text-center text-sm"
            >
              Create Account
            </button>
          </form>
        )}

        {/* 3. Forgot Password View */}
        {mode === 'forgot' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <button
                onClick={() => setMode('login')}
                className="text-cyan-400 hover:text-cyan-300 text-xs font-semibold"
              >
                &larr; Back to Login
              </button>
              <span className="text-slate-600">|</span>
              <span className="text-xs text-slate-400">Password Recovery</span>
            </div>

            {forgotStep === 1 ? (
              <form onSubmit={handleForgotPasswordVerify} className="space-y-4">
                <div className="p-3 bg-cyan-950/40 border border-cyan-800/50 rounded-xl flex gap-3 items-start">
                  <HelpCircle className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-cyan-300">
                    Enter the email and mobile number associated with your account to verify identity.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Registered Email</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <Mail className="w-5 h-5" />
                    </span>
                    <input
                      type="email"
                      required
                      placeholder="name@example.com"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Registered Phone</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <Phone className="w-5 h-5" />
                    </span>
                    <input
                      type="tel"
                      required
                      placeholder="98XXXXXXXX"
                      value={forgotPhone}
                      onChange={(e) => setForgotPhone(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 px-4 rounded-xl shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all cursor-pointer text-center text-sm"
                >
                  Verify Account
                </button>
              </form>
            ) : (
              <form onSubmit={handleForgotPasswordReset} className="space-y-4">
                <div className="p-3 bg-violet-950/40 border border-violet-800/50 rounded-xl flex gap-3 items-start animate-pulse">
                  <AlertTriangle className="w-5 h-5 text-violet-400 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-violet-300">
                    Identity Verified! Please enter a new password below. Do not share this with anyone.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">New Password</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <Lock className="w-5 h-5" />
                    </span>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Confirm New Password</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <Lock className="w-5 h-5" />
                    </span>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full mt-2 bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-white font-bold py-3 px-4 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all cursor-pointer text-center text-sm"
                >
                  Save New Password & Log In
                </button>
              </form>
            )}
          </div>
        )}

        {/* 4. Admin Login View */}
        {mode === 'admin' && (
          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div className="p-3 bg-red-950/40 border border-red-800/50 rounded-xl flex gap-3 items-start mb-4">
              <ShieldCheck className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-red-300">
                You are accessing the Admin Management Console. Unauthorized access attempts are monitored and logged.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Admin Email</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Mail className="w-5 h-5" />
                </span>
                <input
                  type="email"
                  required
                  placeholder="admin@nimzbattle.com"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Admin Password</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Lock className="w-5 h-5" />
                </span>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl py-3 pl-10 pr-4 text-white placeholder-slate-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-4 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold py-3 px-4 rounded-xl shadow-[0_0_20px_rgba(220,38,38,0.3)] hover:shadow-[0_0_25px_rgba(220,38,38,0.5)] transition-all cursor-pointer text-center text-sm"
            >
              Authenticate Admin
            </button>
            
            <div className="text-center mt-2">
              <span className="text-[11px] text-slate-500">Admin default pass is: admin123</span>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
