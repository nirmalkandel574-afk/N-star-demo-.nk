import { useState, useEffect } from 'react';
import { 
  User, Tournament, initializeDB, getAnnouncements, addLog 
} from './utils/db';
import { AuthModals } from './components/AuthModals';
import { LandingPage } from './components/LandingPage';
import { UserDashboard } from './components/UserDashboard';
import { AdminPanel } from './components/AdminPanel';
import { LogIn, UserPlus, LayoutDashboard, ShieldAlert, X, Volume2 } from 'lucide-react';

export default function App() {
  // Initialize Database
  useEffect(() => {
    initializeDB();
  }, []);

  // Application States
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = sessionStorage.getItem('nimz_current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [currentView, setCurrentView] = useState<'landing' | 'dashboard' | 'admin'>('landing');
  const [dashboardTab, setDashboardTab] = useState<string>('profile');
  
  // Auth Modal States
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot' | 'admin'>('login');
  
  // Toast Notification State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Active Announcements
  const [announcements, setAnnouncements] = useState<any[]>([]);

  // Check URL Referral Parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refCode = params.get('ref');
    if (refCode) {
      // Clean query parameter from URL bar without refreshing
      window.history.replaceState({}, document.title, window.location.pathname);
      
      // Open register modal automatically and save code to sessionStorage for pre-fill
      sessionStorage.setItem('nimz_temp_ref', refCode.toUpperCase());
      setAuthModalMode('register');
      setAuthModalOpen(true);
      notify(`Referred by user code: ${refCode.toUpperCase()}! Pre-filled on signup.`, 'info');
    }

    // Load active announcements
    setAnnouncements(getAnnouncements());
  }, []);

  const notify = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  };

  // Auto hide toast
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const handleLoginSuccess = (user: User) => {
    sessionStorage.setItem('nimz_current_user', JSON.stringify(user));
    setCurrentUser(user);
    
    if (user.role === 'admin') {
      setCurrentView('admin');
    } else {
      setCurrentView('dashboard');
      setDashboardTab('profile');
    }
  };

  const handleLogout = () => {
    if (currentUser) {
      addLog(currentUser.id, currentUser.username, 'User logged out of platform');
    }
    sessionStorage.removeItem('nimz_current_user');
    setCurrentUser(null);
    setCurrentView('landing');
    notify('Logged out successfully!', 'info');
  };

  // Sync current user attributes (wallet details, credentials, etc.)
  const handleUpdateUser = (updatedUser: User) => {
    sessionStorage.setItem('nimz_current_user', JSON.stringify(updatedUser));
    setCurrentUser(updatedUser);
  };

  const handleJoinTournamentClick = (_tournament: Tournament) => {
    if (!currentUser) {
      setAuthModalMode('login');
      setAuthModalOpen(true);
      notify('Please log in or sign up to join esports tournaments.', 'info');
      return;
    }

    if (currentUser.role === 'admin') {
      notify('Administrators cannot register as players in matches.', 'error');
      return;
    }

    // Redirect to dashboard tournaments tab and trigger join flow inside dashboard
    setCurrentView('dashboard');
    setDashboardTab('tournaments');
  };

  const handleNavigateToDashboard = (tab?: string) => {
    if (currentUser) {
      setCurrentView(currentUser.role === 'admin' ? 'admin' : 'dashboard');
      if (tab) setDashboardTab(tab);
    } else {
      setAuthModalMode('login');
      setAuthModalOpen(true);
    }
  };

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen font-sans flex flex-col justify-between selection:bg-cyan-500 selection:text-black">
      
      {/* 1. Header / Navbar */}
      <header className="fixed top-0 inset-x-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-900">
        
        {/* Active Announcement Marquee Banner */}
        {announcements.length > 0 && (
          <div className="bg-gradient-to-r from-violet-900 to-cyan-900 text-white py-2.5 px-4 text-xs font-semibold flex items-center justify-between shadow-inner relative overflow-hidden">
            <div className="flex items-center gap-2 overflow-hidden w-full relative h-6">
              <Volume2 className="w-4 h-4 text-cyan-400 flex-shrink-0 z-10 animate-pulse bg-gradient-to-r from-violet-900 via-violet-900/90 to-transparent pr-1" />
              <div className="flex gap-16 whitespace-nowrap animate-marquee hover:[animation-play-state:paused] absolute left-6">
                {announcements.map((ann) => (
                  <span key={ann.id} className="inline-flex items-center gap-2 text-slate-150">
                    <span className="text-cyan-400 font-extrabold uppercase bg-slate-950/55 px-2 py-0.5 rounded border border-cyan-800/40 text-[8px]">
                      {ann.type}
                    </span>
                    <span className="font-bold text-white">{ann.title}:</span> {ann.content}
                  </span>
                ))}
              </div>
            </div>
            
            <button 
              onClick={() => setAnnouncements([])} 
              className="text-slate-400 hover:text-white transition-colors pl-3 flex-shrink-0 z-15"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex justify-between items-center">
          
          {/* Logo brand */}
          <button 
            onClick={() => setCurrentView('landing')}
            className="flex items-center gap-3 group text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 shadow-[0_0_15px_rgba(6,182,212,0.4)] flex items-center justify-center font-black text-white text-lg transition-transform group-hover:scale-105">
              N
            </div>
            <div>
              <h1 className="text-xl font-black tracking-wider text-white uppercase leading-none">
                NIMZ <span className="bg-gradient-to-r from-cyan-400 to-violet-400 bg-clip-text text-transparent">BATTLE</span>
              </h1>
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">Esports Arena</p>
            </div>
          </button>

          {/* Nav items */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-bold">
            <button
              onClick={() => {
                setCurrentView('landing');
                setTimeout(() => document.getElementById('tournaments')?.scrollIntoView({ behavior: 'smooth' }), 100);
              }}
              className="text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Tournaments
            </button>
            <button
              onClick={() => {
                setCurrentView('landing');
                setTimeout(() => document.getElementById('leaderboard')?.scrollIntoView({ behavior: 'smooth' }), 100);
              }}
              className="text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Leaderboard
            </button>
            <button
              onClick={() => {
                setCurrentView('landing');
                setTimeout(() => document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' }), 100);
              }}
              className="text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              FAQs
            </button>
            <button
              onClick={() => {
                setCurrentView('landing');
                setTimeout(() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }), 100);
              }}
              className="text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
            >
              Contact Us
            </button>
          </nav>

          {/* Auth Action Buttons */}
          <div className="flex items-center gap-3">
            {currentUser ? (
              <>
                <button
                  onClick={() => setCurrentView(currentUser.role === 'admin' ? 'admin' : 'dashboard')}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-bold text-slate-200 hover:text-cyan-400 hover:border-cyan-800 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  {currentUser.role === 'admin' ? (
                    <>
                      <ShieldAlert className="w-4 h-4 text-red-500" />
                      Admin Panel
                    </>
                  ) : (
                    <>
                      <LayoutDashboard className="w-4 h-4 text-cyan-400" />
                      Dashboard
                    </>
                  )}
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-650 to-amber-600 hover:from-red-500 hover:to-amber-500 text-xs font-bold text-white transition-all cursor-pointer"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    setAuthModalMode('login');
                    setAuthModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 text-xs font-bold text-white border border-slate-800 hover:border-cyan-800 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <LogIn className="w-4 h-4 text-cyan-400" />
                  Sign In
                </button>
                <button
                  onClick={() => {
                    setAuthModalMode('register');
                    setAuthModalOpen(true);
                  }}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-600 hover:from-cyan-400 hover:to-violet-500 text-xs font-bold text-white transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  Sign Up
                </button>
              </>
            )}
          </div>

        </div>
      </header>

      {/* 2. Content Router */}
      <div className="flex-grow pt-20">
        {currentView === 'landing' && (
          <LandingPage
            onJoinClick={handleJoinTournamentClick}
            onOpenAuth={(mode) => {
              setAuthModalMode(mode);
              setAuthModalOpen(true);
            }}
            currentUser={currentUser}
            onNavigateToDashboard={handleNavigateToDashboard}
            notify={notify}
          />
        )}

        {currentView === 'dashboard' && currentUser && (
          <UserDashboard
            currentUser={currentUser}
            onLogout={handleLogout}
            onUpdateUser={handleUpdateUser}
            notify={notify}
            initialTab={dashboardTab}
          />
        )}

        {currentView === 'admin' && currentUser && (
          <AdminPanel
            currentUser={currentUser}
            onLogout={handleLogout}
            notify={notify}
          />
        )}
      </div>

      {/* 3. Global Toast Notifications */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-300 max-w-sm w-full">
          <div className={`p-4 rounded-2xl border shadow-xl flex justify-between items-start gap-4 ${
            toast.type === 'success' 
              ? 'bg-emerald-950 border-emerald-800 text-emerald-300 shadow-emerald-900/10' 
              : toast.type === 'error' 
              ? 'bg-red-950 border-red-900 text-red-300 shadow-red-900/10' 
              : 'bg-cyan-950 border-cyan-800 text-cyan-300 shadow-cyan-900/10'
          }`}>
            <p className="text-xs font-semibold leading-relaxed">{toast.message}</p>
            <button 
              onClick={() => setToast(null)}
              className="text-slate-400 hover:text-white transition-colors flex-shrink-0"
            >
              &times;
            </button>
          </div>
        </div>
      )}

      {/* 4. Global Auth Modal Overlay */}
      <AuthModals
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        initialMode={authModalMode}
        notify={notify}
      />

    </div>
  );
}
