// Nimz Battle LocalStorage Database and State Helpers

export interface User {
  id: string;
  username: string;
  email: string;
  role: 'user' | 'admin';
  walletBalance: number;
  bonusCoins: number;
  avatarUrl: string;
  referralCode: string;
  referredBy: string | null;
  referralsCount: number;
  referralEarnings: number;
  status: 'active' | 'banned';
  badges: string[];
  createdAt: string;
  phone: string;
  gameNicknames: {
    freeFire?: string;
    pubg?: string;
    mlbb?: string;
    efootball?: string;
  };
  lastLoginDate?: string;
  lastSpinDate?: string;
}

export interface Tournament {
  id: string;
  title: string;
  game: 'Free Fire' | 'PUBG Mobile' | 'Mobile Legends' | 'eFootball' | 'Other';
  format: 'Solo' | 'Duo' | 'Squad';
  bracketType: 'Single Elimination' | 'Double Elimination' | 'Round Robin';
  entryFee: number; // in Rs.
  prizePool: number; // in Rs.
  totalSlots: number;
  registeredPlayers: string[]; // User IDs
  participants: Array<{
    userId: string;
    username: string;
    gameNickname: string;
  }>;
  status: 'upcoming' | 'ongoing' | 'completed';
  startTime: string; // ISO string
  roomDetails?: {
    roomId: string;
    roomPassword?: string;
  };
  winners?: Array<{
    rank: number;
    username: string;
    prize: number;
  }>;
  rules: string[];
  bannerUrl: string;
}

export interface Transaction {
  id: string;
  userId: string;
  username: string;
  type: 'deposit' | 'withdrawal' | 'referral' | 'tournament_entry' | 'tournament_win' | 'daily_spin' | 'daily_login';
  amount: number;
  method?: 'eSewa' | 'Khalti' | 'System';
  accountNo?: string;
  accountName?: string;
  transactionId?: string;
  screenshotUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface SpinReward {
  id: string;
  type: 'wallet' | 'coins' | 'free_entry' | 'cashback' | 'better_luck';
  value: number; // value in money, coins or coupon
  label: string;
  probability: number; // out of 100
}

export interface SpinLog {
  id: string;
  userId: string;
  username: string;
  rewardLabel: string;
  rewardType: string;
  rewardValue: number;
  createdAt: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'info' | 'warning' | 'success';
  createdAt: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  username: string;
  action: string;
  ip?: string;
  createdAt: string;
}

// Configurable Admin Details
export interface AdminConfig {
  esewaQrUrl: string;
  esewaPhone: string;
  khaltiQrUrl: string;
  khaltiPhone: string;
  referralReward: number; // Rs. 2.50
  minDeposit: number; // Rs. 10
  minWithdraw: number; // Rs. 50
  spinRewards: SpinReward[];
}

const DEFAULT_SPIN_REWARDS: SpinReward[] = [
  { id: '1', type: 'wallet', value: 5, label: 'Rs. 5 Wallet Cash', probability: 15 },
  { id: '2', type: 'coins', value: 50, label: '50 Bonus Coins', probability: 25 },
  { id: '3', type: 'wallet', value: 10, label: 'Rs. 10 Wallet Cash', probability: 5 },
  { id: '4', type: 'free_entry', value: 0, label: 'Free Ticket (Rs. 10 Value)', probability: 10 },
  { id: '5', type: 'cashback', value: 2, label: 'Rs. 2 Cashback', probability: 20 },
  { id: '6', type: 'better_luck', value: 0, label: 'Try Again Tomorrow', probability: 25 },
];

const DEFAULT_ADMIN_CONFIG: AdminConfig = {
  esewaQrUrl: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=400',
  esewaPhone: '9841234567',
  khaltiQrUrl: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=400',
  khaltiPhone: '9812345678',
  referralReward: 2.5,
  minDeposit: 10,
  minWithdraw: 50,
  spinRewards: DEFAULT_SPIN_REWARDS,
};

const DEFAULT_FAQS: FAQItem[] = [
  { id: '1', question: 'How can I join a tournament?', answer: 'To join a tournament, register or log in to your account, make sure you have sufficient balance (or find a free tournament), select a tournament from the list, input your game nickname, and click Join. The room details will be visible on the tournament page 15 minutes before the match start.' },
  { id: '2', question: 'How do I deposit money using eSewa or Khalti?', answer: 'Go to your Wallet dashboard, click on Deposit, select eSewa or Khalti. You will see the admin QR code and phone number. Make the payment, note down the transaction ID, take a screenshot, fill out the deposit form in the app, and submit. The admin will review and approve your request within 5-15 minutes.' },
  { id: '3', question: 'What is the minimum deposit and withdrawal limit?', answer: 'The minimum deposit amount is Rs. 10. The minimum withdrawal amount is Rs. 50.' },
  { id: '4', question: 'How does the Referral system work?', answer: 'Every user gets a unique referral code and referral link. Share it with your friends. Once they register using your code and make a successful deposit or verify their profile, you will instantly earn Rs. 2.50 in your wallet.' },
  { id: '5', question: 'Are tournament results verified?', answer: 'Yes! Our admin team monitors all matches. Room screenshots and results are analyzed, and final standings are published within 1 hour of match completion. Prizes are automatically credited to the winners\' wallet.' },
];

// Helper database initialization
export const initializeDB = () => {
  if (!localStorage.getItem('nimz_users')) {
    const initialUsers: User[] = [
      {
        id: 'admin_1',
        username: 'NimzAdmin',
        email: 'admin@nimzbattle.com',
        role: 'admin',
        walletBalance: 12500,
        bonusCoins: 1000,
        avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=NimzAdmin',
        referralCode: 'NIMZADMIN',
        referredBy: null,
        referralsCount: 15,
        referralEarnings: 37.5,
        status: 'active',
        badges: ['Platform Founder', 'Super Admin'],
        createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        phone: '9800000000',
        gameNicknames: {}
      },
      {
        id: 'user_1',
        username: 'GamerPro99',
        email: 'gamer@nimzbattle.com',
        role: 'user',
        walletBalance: 245,
        bonusCoins: 350,
        avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=GamerPro99',
        referralCode: 'GAMERPRO99',
        referredBy: null,
        referralsCount: 8,
        referralEarnings: 20.0,
        status: 'active',
        badges: ['Early Adopter', 'Top Recruiter'],
        createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        phone: '9845123456',
        gameNicknames: { freeFire: 'FF_ProGamer', pubg: 'PUBG_Killer' }
      },
      {
        id: 'user_2',
        username: 'Ninja_MLBB',
        email: 'ninja@nimzbattle.com',
        role: 'user',
        walletBalance: 80,
        bonusCoins: 120,
        avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ninja_MLBB',
        referralCode: 'NINJAML',
        referredBy: 'GAMERPRO99',
        referralsCount: 3,
        referralEarnings: 7.5,
        status: 'active',
        badges: ['Esports Champ'],
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        phone: '9815987654',
        gameNicknames: { mlbb: 'MLBB_Ninja_X' }
      },
      {
        id: 'user_3',
        username: 'SlayerX',
        email: 'slayer@nimzbattle.com',
        role: 'user',
        walletBalance: 15,
        bonusCoins: 50,
        avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=SlayerX',
        referralCode: 'SLAYERX',
        referredBy: 'GAMERPRO99',
        referralsCount: 0,
        referralEarnings: 0,
        status: 'active',
        badges: ['Newbie'],
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        phone: '9801122334',
        gameNicknames: { freeFire: 'Slayer_FF' }
      }
    ];
    localStorage.setItem('nimz_users', JSON.stringify(initialUsers));
  }

  if (!localStorage.getItem('nimz_tournaments')) {
    const initialTournaments: Tournament[] = [
      {
        id: 'tour_1',
        title: 'Free Fire Weekend Showdown',
        game: 'Free Fire',
        format: 'Squad',
        bracketType: 'Single Elimination',
        entryFee: 20,
        prizePool: 1000,
        totalSlots: 24,
        registeredPlayers: ['user_1', 'user_2'],
        participants: [
          { userId: 'user_1', username: 'GamerPro99', gameNickname: 'FF_ProGamer' },
          { userId: 'user_2', username: 'Ninja_MLBB', gameNickname: 'FF_Ninja' }
        ],
        status: 'upcoming',
        startTime: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days from now
        rules: [
          'Hackers will be banned immediately.',
          'Screenshots must be provided in case of conflicts.',
          'Teaming with other squads is prohibited.',
          'Join the room 10 minutes prior to match time.'
        ],
        bannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=800'
      },
      {
        id: 'tour_2',
        title: 'PUBG Mobile Neo Championship',
        game: 'PUBG Mobile',
        format: 'Solo',
        bracketType: 'Single Elimination',
        entryFee: 15,
        prizePool: 800,
        totalSlots: 50,
        registeredPlayers: ['user_1'],
        participants: [
          { userId: 'user_1', username: 'GamerPro99', gameNickname: 'PUBG_Killer' }
        ],
        status: 'upcoming',
        startTime: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // 4 hours from now
        rules: [
          'Emulators not allowed.',
          'Forming temporary alliances is forbidden.',
          'Minimum level required: 30.',
          'Ensure high internet speed before joining.'
        ],
        bannerUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&q=80&w=800'
      },
      {
        id: 'tour_3',
        title: 'Mobile Legends Bang Bang Rush',
        game: 'Mobile Legends',
        format: 'Squad',
        bracketType: 'Double Elimination',
        entryFee: 50,
        prizePool: 2500,
        totalSlots: 16,
        registeredPlayers: ['user_2'],
        participants: [
          { userId: 'user_2', username: 'Ninja_MLBB', gameNickname: 'MLBB_Ninja_X' }
        ],
        status: 'ongoing',
        startTime: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // started 30 mins ago
        roomDetails: {
          roomId: 'MLBB-NEO-991',
          roomPassword: 'nimzpassworld'
        },
        rules: [
          'Lag issues must be resolved by players.',
          'No skins are restricted unless agreed.',
          'Chat abuses will result in team disqualification.'
        ],
        bannerUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=800'
      },
      {
        id: 'tour_4',
        title: 'eFootball Cup Season 12',
        game: 'eFootball',
        format: 'Solo',
        bracketType: 'Round Robin',
        entryFee: 10,
        prizePool: 500,
        totalSlots: 32,
        registeredPlayers: ['user_1', 'user_2', 'user_3'],
        participants: [
          { userId: 'user_1', username: 'GamerPro99', gameNickname: 'PES_Gamer' },
          { userId: 'user_2', username: 'Ninja_MLBB', gameNickname: 'PES_Ninja' },
          { userId: 'user_3', username: 'SlayerX', gameNickname: 'PES_Slayer' }
        ],
        status: 'completed',
        startTime: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        winners: [
          { rank: 1, username: 'GamerPro99', prize: 300 },
          { rank: 2, username: 'Ninja_MLBB', prize: 150 },
          { rank: 3, username: 'SlayerX', prize: 50 }
        ],
        rules: [
          'Matches are 10 minutes length.',
          'Standard team ratings only.',
          'Provide game result screenshots.'
        ],
        bannerUrl: 'https://images.unsplash.com/photo-1612287230202-1bf1d85d1bdf?auto=format&fit=crop&q=80&w=800'
      }
    ];
    localStorage.setItem('nimz_tournaments', JSON.stringify(initialTournaments));
  }

  if (!localStorage.getItem('nimz_transactions')) {
    const initialTransactions: Transaction[] = [
      {
        id: 'tx_1',
        userId: 'user_1',
        username: 'GamerPro99',
        type: 'deposit',
        amount: 200,
        method: 'eSewa',
        transactionId: 'TXN89123847',
        screenshotUrl: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=400',
        status: 'approved',
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'tx_2',
        userId: 'user_1',
        username: 'GamerPro99',
        type: 'referral',
        amount: 2.5,
        method: 'System',
        status: 'approved',
        createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'tx_3',
        userId: 'user_2',
        username: 'Ninja_MLBB',
        type: 'deposit',
        amount: 100,
        method: 'Khalti',
        transactionId: 'TXN23749811',
        screenshotUrl: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=400',
        status: 'approved',
        createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'tx_4',
        userId: 'user_1',
        username: 'GamerPro99',
        type: 'tournament_win',
        amount: 300,
        method: 'System',
        status: 'approved',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'tx_5',
        userId: 'user_3',
        username: 'SlayerX',
        type: 'deposit',
        amount: 50,
        method: 'eSewa',
        transactionId: 'TXN88921122',
        screenshotUrl: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=400',
        status: 'pending',
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString() // 1 hour ago
      },
      {
        id: 'tx_6',
        userId: 'user_2',
        username: 'Ninja_MLBB',
        type: 'withdrawal',
        amount: 50,
        method: 'Khalti',
        accountNo: '9815987654',
        accountName: 'Sanjay Bahadur',
        status: 'pending',
        createdAt: new Date(Date.now() - 30 * 60 * 1000).toISOString() // 30 mins ago
      }
    ];
    localStorage.setItem('nimz_transactions', JSON.stringify(initialTransactions));
  }

  if (!localStorage.getItem('nimz_spins')) {
    const initialSpins: SpinLog[] = [
      {
        id: 'spin_1',
        userId: 'user_1',
        username: 'GamerPro99',
        rewardLabel: 'Rs. 5 Wallet Cash',
        rewardType: 'wallet',
        rewardValue: 5,
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];
    localStorage.setItem('nimz_spins', JSON.stringify(initialSpins));
  }

  if (!localStorage.getItem('nimz_faqs')) {
    localStorage.setItem('nimz_faqs', JSON.stringify(DEFAULT_FAQS));
  }

  if (!localStorage.getItem('nimz_announcements')) {
    const initialAnnouncements: Announcement[] = [
      {
        id: 'ann_1',
        title: '🔥 New Free Fire Tournament Live Now!',
        content: 'Registration is open for Free Fire Weekend Showdown. Prize pool is Rs. 1000. Limited slots available, join now!',
        type: 'success',
        createdAt: new Date().toISOString()
      },
      {
        id: 'ann_2',
        title: '⚠️ Wallet System Maintenance',
        content: 'Deposit approval may take up to 20 minutes between 10 PM and 7 AM due to automated system updates.',
        type: 'warning',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];
    localStorage.setItem('nimz_announcements', JSON.stringify(initialAnnouncements));
  }

  if (!localStorage.getItem('nimz_config')) {
    localStorage.setItem('nimz_config', JSON.stringify(DEFAULT_ADMIN_CONFIG));
  }

  if (!localStorage.getItem('nimz_logs')) {
    const initialLogs: ActivityLog[] = [
      {
        id: 'log_1',
        userId: 'user_1',
        username: 'GamerPro99',
        action: 'User Registered on Platform',
        ip: '192.168.1.45',
        createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 'log_2',
        userId: 'user_1',
        username: 'GamerPro99',
        action: 'Deposited Rs. 200 via eSewa',
        ip: '192.168.1.45',
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];
    localStorage.setItem('nimz_logs', JSON.stringify(initialLogs));
  }
};

// Database Getters
export const getUsers = (): User[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_users') || '[]');
};

export const getTournaments = (): Tournament[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_tournaments') || '[]');
};

export const getTransactions = (): Transaction[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_transactions') || '[]');
};

export const getSpins = (): SpinLog[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_spins') || '[]');
};

export const getFAQs = (): FAQItem[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_faqs') || '[]');
};

export const getAnnouncements = (): Announcement[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_announcements') || '[]');
};

export const getConfig = (): AdminConfig => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_config') || JSON.stringify(DEFAULT_ADMIN_CONFIG));
};

export const getLogs = (): ActivityLog[] => {
  initializeDB();
  return JSON.parse(localStorage.getItem('nimz_logs') || '[]');
};

// Database Setters & Triggers
export const saveUsers = (users: User[]) => {
  localStorage.setItem('nimz_users', JSON.stringify(users));
};

export const saveTournaments = (tournaments: Tournament[]) => {
  localStorage.setItem('nimz_tournaments', JSON.stringify(tournaments));
};

export const saveTransactions = (tx: Transaction[]) => {
  localStorage.setItem('nimz_transactions', JSON.stringify(tx));
};

export const saveSpins = (spins: SpinLog[]) => {
  localStorage.setItem('nimz_spins', JSON.stringify(spins));
};

export const saveFAQs = (faqs: FAQItem[]) => {
  localStorage.setItem('nimz_faqs', JSON.stringify(faqs));
};

export const saveAnnouncements = (anns: Announcement[]) => {
  localStorage.setItem('nimz_announcements', JSON.stringify(anns));
};

export const saveConfig = (config: AdminConfig) => {
  localStorage.setItem('nimz_config', JSON.stringify(config));
};

export const addLog = (userId: string, username: string, action: string) => {
  const logs = getLogs();
  const newLog: ActivityLog = {
    id: 'log_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
    userId,
    username,
    action,
    ip: '192.168.' + Math.floor(Math.random() * 255) + '.' + Math.floor(Math.random() * 255),
    createdAt: new Date().toISOString()
  };
  logs.unshift(newLog);
  localStorage.setItem('nimz_logs', JSON.stringify(logs.slice(0, 100))); // keep last 100 logs
};
